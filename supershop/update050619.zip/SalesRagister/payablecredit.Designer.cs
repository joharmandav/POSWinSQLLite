﻿namespace supershop
{
    partial class payablecredit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(payablecredit));
            this.ComboCustID = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtReceiveDate = new System.Windows.Forms.DateTimePicker();
            this.txtReceive = new System.Windows.Forms.TextBox();
            this.lbreceiveamt = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMsg = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.RefrashPayby = new System.Windows.Forms.Button();
            this.labelPayby = new System.Windows.Forms.Label();
            this.CombPayby = new System.Windows.Forms.ComboBox();
            this.txttotalamt = new System.Windows.Forms.TextBox();
            this.txtAfterPaid = new System.Windows.Forms.TextBox();
            this.txtRefrance = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.ComboInvoice = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ComboCustID
            // 
            this.ComboCustID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ComboCustID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ComboCustID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ComboCustID.FormattingEnabled = true;
            this.ComboCustID.Location = new System.Drawing.Point(47, 46);
            this.ComboCustID.Name = "ComboCustID";
            this.ComboCustID.Size = new System.Drawing.Size(221, 24);
            this.ComboCustID.TabIndex = 172;
            this.ComboCustID.SelectedIndexChanged += new System.EventHandler(this.ComboCustID_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label7.Location = new System.Drawing.Point(325, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 176;
            this.label7.Text = "Receive Date:";
            // 
            // dtReceiveDate
            // 
            this.dtReceiveDate.CustomFormat = "";
            this.dtReceiveDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtReceiveDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtReceiveDate.Location = new System.Drawing.Point(327, 98);
            this.dtReceiveDate.Name = "dtReceiveDate";
            this.dtReceiveDate.Size = new System.Drawing.Size(129, 22);
            this.dtReceiveDate.TabIndex = 175;
            // 
            // txtReceive
            // 
            this.txtReceive.Location = new System.Drawing.Point(47, 211);
            this.txtReceive.Name = "txtReceive";
            this.txtReceive.Size = new System.Drawing.Size(221, 20);
            this.txtReceive.TabIndex = 177;
            this.txtReceive.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtReceive_KeyDown);
            this.txtReceive.Leave += new System.EventHandler(this.txtReceive_Leave);
            // 
            // lbreceiveamt
            // 
            this.lbreceiveamt.AutoSize = true;
            this.lbreceiveamt.Location = new System.Drawing.Point(45, 195);
            this.lbreceiveamt.Name = "lbreceiveamt";
            this.lbreceiveamt.Size = new System.Drawing.Size(73, 13);
            this.lbreceiveamt.TabIndex = 179;
            this.lbreceiveamt.Text = "Paid Amount :";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Green;
            this.btnSave.Enabled = false;
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.Yellow;
            this.btnSave.Location = new System.Drawing.Point(48, 264);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(129, 30);
            this.btnSave.TabIndex = 178;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(324, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 16);
            this.label4.TabIndex = 180;
            this.label4.Text = "Total Payable Amont :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(329, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 185;
            this.label1.Text = "After Paid :";
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMsg.Location = new System.Drawing.Point(44, 319);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(15, 20);
            this.lblMsg.TabIndex = 186;
            this.lblMsg.Text = "-";
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.Crimson;
            this.btnReset.FlatAppearance.BorderSize = 0;
            this.btnReset.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btnReset.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReset.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnReset.ForeColor = System.Drawing.SystemColors.Window;
            this.btnReset.Location = new System.Drawing.Point(327, 264);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(97, 28);
            this.btnReset.TabIndex = 187;
            this.btnReset.Text = "Exit";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel4.Location = new System.Drawing.Point(217, 87);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(51, 13);
            this.linkLabel4.TabIndex = 209;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "Add New";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // RefrashPayby
            // 
            this.RefrashPayby.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.RefrashPayby.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.RefrashPayby.FlatAppearance.BorderSize = 0;
            this.RefrashPayby.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.RefrashPayby.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RefrashPayby.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.RefrashPayby.Image = ((System.Drawing.Image)(resources.GetObject("RefrashPayby.Image")));
            this.RefrashPayby.Location = new System.Drawing.Point(273, 102);
            this.RefrashPayby.Name = "RefrashPayby";
            this.RefrashPayby.Size = new System.Drawing.Size(25, 25);
            this.RefrashPayby.TabIndex = 208;
            this.RefrashPayby.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.RefrashPayby.UseVisualStyleBackColor = false;
            this.RefrashPayby.Click += new System.EventHandler(this.RefrashPayby_Click);
            // 
            // labelPayby
            // 
            this.labelPayby.AutoSize = true;
            this.labelPayby.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPayby.Location = new System.Drawing.Point(45, 87);
            this.labelPayby.Name = "labelPayby";
            this.labelPayby.Size = new System.Drawing.Size(45, 13);
            this.labelPayby.TabIndex = 207;
            this.labelPayby.Text = "Pay by :";
            // 
            // CombPayby
            // 
            this.CombPayby.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CombPayby.FormattingEnabled = true;
            this.CombPayby.Location = new System.Drawing.Point(48, 106);
            this.CombPayby.Name = "CombPayby";
            this.CombPayby.Size = new System.Drawing.Size(220, 21);
            this.CombPayby.TabIndex = 206;
            this.CombPayby.Text = "Cash";
            // 
            // txttotalamt
            // 
            this.txttotalamt.Enabled = false;
            this.txttotalamt.Location = new System.Drawing.Point(327, 158);
            this.txttotalamt.Name = "txttotalamt";
            this.txttotalamt.Size = new System.Drawing.Size(129, 20);
            this.txttotalamt.TabIndex = 210;
            this.txttotalamt.Text = "0";
            // 
            // txtAfterPaid
            // 
            this.txtAfterPaid.Enabled = false;
            this.txtAfterPaid.Location = new System.Drawing.Point(327, 211);
            this.txtAfterPaid.Name = "txtAfterPaid";
            this.txtAfterPaid.Size = new System.Drawing.Size(129, 20);
            this.txtAfterPaid.TabIndex = 211;
            this.txtAfterPaid.Text = "0";
            // 
            // txtRefrance
            // 
            this.txtRefrance.Location = new System.Drawing.Point(47, 159);
            this.txtRefrance.Name = "txtRefrance";
            this.txtRefrance.Size = new System.Drawing.Size(221, 20);
            this.txtRefrance.TabIndex = 212;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 213;
            this.label2.Text = "Reference #";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel1.Location = new System.Drawing.Point(45, 30);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(60, 13);
            this.linkLabel1.TabIndex = 214;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Customer  :";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // ComboInvoice
            // 
            this.ComboInvoice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ComboInvoice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ComboInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ComboInvoice.FormattingEnabled = true;
            this.ComboInvoice.Location = new System.Drawing.Point(332, 46);
            this.ComboInvoice.Name = "ComboInvoice";
            this.ComboInvoice.Size = new System.Drawing.Size(124, 24);
            this.ComboInvoice.TabIndex = 215;
            this.ComboInvoice.SelectedIndexChanged += new System.EventHandler(this.ComboInvoice_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(329, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 216;
            this.label3.Text = "Invoice # :";
            // 
            // payablecredit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(498, 384);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ComboInvoice);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.txtRefrance);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAfterPaid);
            this.Controls.Add(this.txttotalamt);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.RefrashPayby);
            this.Controls.Add(this.labelPayby);
            this.Controls.Add(this.CombPayby);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtReceive);
            this.Controls.Add(this.lbreceiveamt);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtReceiveDate);
            this.Controls.Add(this.ComboCustID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "payablecredit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Credit Payable";
            this.Load += new System.EventHandler(this.payablecredit_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.payablecredit_MouseDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ComboCustID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtReceiveDate;
        private System.Windows.Forms.TextBox txtReceive;
        private System.Windows.Forms.Label lbreceiveamt;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.Button RefrashPayby;
        private System.Windows.Forms.Label labelPayby;
        private System.Windows.Forms.ComboBox CombPayby;
        private System.Windows.Forms.TextBox txttotalamt;
        private System.Windows.Forms.TextBox txtAfterPaid;
        private System.Windows.Forms.TextBox txtRefrance;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.ComboBox ComboInvoice;
        private System.Windows.Forms.Label label3;
    }
}