﻿namespace supershop.SalesRagister
{
    partial class Currency_Shortcuts
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Currency_Shortcuts));
            this.btnCoinOne = new System.Windows.Forms.Button();
            this.btnCoinTwo = new System.Windows.Forms.Button();
            this.btnPaper5 = new System.Windows.Forms.Button();
            this.btnPaper10 = new System.Windows.Forms.Button();
            this.btnPaper20 = new System.Windows.Forms.Button();
            this.btnPaper50 = new System.Windows.Forms.Button();
            this.btnPaper100 = new System.Windows.Forms.Button();
            this.btnNum1 = new System.Windows.Forms.Button();
            this.btnNum4 = new System.Windows.Forms.Button();
            this.btnNum7 = new System.Windows.Forms.Button();
            this.btnDecimal = new System.Windows.Forms.Button();
            this.btnNum0 = new System.Windows.Forms.Button();
            this.btnNum8 = new System.Windows.Forms.Button();
            this.btnNum5 = new System.Windows.Forms.Button();
            this.btnNum2 = new System.Windows.Forms.Button();
            this.btnBackSpace = new System.Windows.Forms.Button();
            this.btnNum9 = new System.Windows.Forms.Button();
            this.btnNum6 = new System.Windows.Forms.Button();
            this.btnNum3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCoinOne
            // 
            this.btnCoinOne.BackColor = System.Drawing.Color.Goldenrod;
            this.btnCoinOne.FlatAppearance.BorderSize = 0;
            this.btnCoinOne.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCoinOne.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnCoinOne.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCoinOne.Location = new System.Drawing.Point(3, 1);
            this.btnCoinOne.Name = "btnCoinOne";
            this.btnCoinOne.Size = new System.Drawing.Size(46, 38);
            this.btnCoinOne.TabIndex = 153;
            this.btnCoinOne.Text = "1";
            this.btnCoinOne.UseVisualStyleBackColor = false;
            this.btnCoinOne.Click += new System.EventHandler(this.btnCoinOne_Click);
            // 
            // btnCoinTwo
            // 
            this.btnCoinTwo.BackColor = System.Drawing.Color.Goldenrod;
            this.btnCoinTwo.FlatAppearance.BorderSize = 0;
            this.btnCoinTwo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCoinTwo.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnCoinTwo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCoinTwo.Location = new System.Drawing.Point(3, 45);
            this.btnCoinTwo.Name = "btnCoinTwo";
            this.btnCoinTwo.Size = new System.Drawing.Size(46, 38);
            this.btnCoinTwo.TabIndex = 154;
            this.btnCoinTwo.Text = "2";
            this.btnCoinTwo.UseVisualStyleBackColor = false;
            this.btnCoinTwo.Click += new System.EventHandler(this.btnCoinTwo_Click);
            // 
            // btnPaper5
            // 
            this.btnPaper5.BackColor = System.Drawing.Color.Goldenrod;
            this.btnPaper5.FlatAppearance.BorderSize = 0;
            this.btnPaper5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaper5.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnPaper5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnPaper5.Location = new System.Drawing.Point(3, 89);
            this.btnPaper5.Name = "btnPaper5";
            this.btnPaper5.Size = new System.Drawing.Size(46, 38);
            this.btnPaper5.TabIndex = 155;
            this.btnPaper5.Text = "5";
            this.btnPaper5.UseVisualStyleBackColor = false;
            this.btnPaper5.Click += new System.EventHandler(this.btnPaper5_Click);
            // 
            // btnPaper10
            // 
            this.btnPaper10.BackColor = System.Drawing.Color.Goldenrod;
            this.btnPaper10.FlatAppearance.BorderSize = 0;
            this.btnPaper10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaper10.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnPaper10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnPaper10.Location = new System.Drawing.Point(3, 133);
            this.btnPaper10.Name = "btnPaper10";
            this.btnPaper10.Size = new System.Drawing.Size(46, 38);
            this.btnPaper10.TabIndex = 156;
            this.btnPaper10.Text = "10";
            this.btnPaper10.UseVisualStyleBackColor = false;
            this.btnPaper10.Click += new System.EventHandler(this.btnPaper10_Click);
            // 
            // btnPaper20
            // 
            this.btnPaper20.BackColor = System.Drawing.Color.Goldenrod;
            this.btnPaper20.FlatAppearance.BorderSize = 0;
            this.btnPaper20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaper20.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnPaper20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnPaper20.Location = new System.Drawing.Point(3, 177);
            this.btnPaper20.Name = "btnPaper20";
            this.btnPaper20.Size = new System.Drawing.Size(46, 38);
            this.btnPaper20.TabIndex = 157;
            this.btnPaper20.Text = "20";
            this.btnPaper20.UseVisualStyleBackColor = false;
            this.btnPaper20.Click += new System.EventHandler(this.btnPaper20_Click);
            // 
            // btnPaper50
            // 
            this.btnPaper50.BackColor = System.Drawing.Color.Goldenrod;
            this.btnPaper50.FlatAppearance.BorderSize = 0;
            this.btnPaper50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaper50.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnPaper50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnPaper50.Location = new System.Drawing.Point(3, 221);
            this.btnPaper50.Name = "btnPaper50";
            this.btnPaper50.Size = new System.Drawing.Size(46, 38);
            this.btnPaper50.TabIndex = 158;
            this.btnPaper50.Text = "50";
            this.btnPaper50.UseVisualStyleBackColor = false;
            this.btnPaper50.Click += new System.EventHandler(this.btnPaper50_Click);
            // 
            // btnPaper100
            // 
            this.btnPaper100.BackColor = System.Drawing.Color.Goldenrod;
            this.btnPaper100.FlatAppearance.BorderSize = 0;
            this.btnPaper100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaper100.Font = new System.Drawing.Font("Trebuchet MS", 11.75F, System.Drawing.FontStyle.Bold);
            this.btnPaper100.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnPaper100.Location = new System.Drawing.Point(3, 265);
            this.btnPaper100.Name = "btnPaper100";
            this.btnPaper100.Size = new System.Drawing.Size(46, 38);
            this.btnPaper100.TabIndex = 159;
            this.btnPaper100.Text = "100";
            this.btnPaper100.UseVisualStyleBackColor = false;
            this.btnPaper100.Click += new System.EventHandler(this.btnPaper100_Click);
            // 
            // btnNum1
            // 
            this.btnNum1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum1.FlatAppearance.BorderSize = 0;
            this.btnNum1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum1.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum1.Location = new System.Drawing.Point(55, 1);
            this.btnNum1.Name = "btnNum1";
            this.btnNum1.Size = new System.Drawing.Size(78, 56);
            this.btnNum1.TabIndex = 160;
            this.btnNum1.Text = "1";
            this.btnNum1.UseVisualStyleBackColor = false;
            this.btnNum1.Click += new System.EventHandler(this.btnNum1_Click);
            // 
            // btnNum4
            // 
            this.btnNum4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum4.FlatAppearance.BorderSize = 0;
            this.btnNum4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum4.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum4.Location = new System.Drawing.Point(55, 63);
            this.btnNum4.Name = "btnNum4";
            this.btnNum4.Size = new System.Drawing.Size(78, 56);
            this.btnNum4.TabIndex = 161;
            this.btnNum4.Text = "4";
            this.btnNum4.UseVisualStyleBackColor = false;
            this.btnNum4.Click += new System.EventHandler(this.btnNum4_Click);
            // 
            // btnNum7
            // 
            this.btnNum7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum7.FlatAppearance.BorderSize = 0;
            this.btnNum7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum7.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum7.Location = new System.Drawing.Point(55, 125);
            this.btnNum7.Name = "btnNum7";
            this.btnNum7.Size = new System.Drawing.Size(78, 56);
            this.btnNum7.TabIndex = 162;
            this.btnNum7.Text = "7";
            this.btnNum7.UseVisualStyleBackColor = false;
            this.btnNum7.Click += new System.EventHandler(this.btnNum7_Click);
            // 
            // btnDecimal
            // 
            this.btnDecimal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnDecimal.FlatAppearance.BorderSize = 0;
            this.btnDecimal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDecimal.Font = new System.Drawing.Font("Trebuchet MS", 17.75F, System.Drawing.FontStyle.Bold);
            this.btnDecimal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnDecimal.Location = new System.Drawing.Point(55, 187);
            this.btnDecimal.Name = "btnDecimal";
            this.btnDecimal.Size = new System.Drawing.Size(78, 56);
            this.btnDecimal.TabIndex = 163;
            this.btnDecimal.Text = ".";
            this.btnDecimal.UseVisualStyleBackColor = false;
            this.btnDecimal.Click += new System.EventHandler(this.btnDecimal_Click);
            // 
            // btnNum0
            // 
            this.btnNum0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum0.FlatAppearance.BorderSize = 0;
            this.btnNum0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum0.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum0.Location = new System.Drawing.Point(139, 187);
            this.btnNum0.Name = "btnNum0";
            this.btnNum0.Size = new System.Drawing.Size(78, 56);
            this.btnNum0.TabIndex = 167;
            this.btnNum0.Text = "0";
            this.btnNum0.UseVisualStyleBackColor = false;
            this.btnNum0.Click += new System.EventHandler(this.btnNum0_Click);
            // 
            // btnNum8
            // 
            this.btnNum8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum8.FlatAppearance.BorderSize = 0;
            this.btnNum8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum8.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum8.Location = new System.Drawing.Point(139, 125);
            this.btnNum8.Name = "btnNum8";
            this.btnNum8.Size = new System.Drawing.Size(78, 56);
            this.btnNum8.TabIndex = 166;
            this.btnNum8.Text = "8";
            this.btnNum8.UseVisualStyleBackColor = false;
            this.btnNum8.Click += new System.EventHandler(this.btnNum8_Click);
            // 
            // btnNum5
            // 
            this.btnNum5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum5.FlatAppearance.BorderSize = 0;
            this.btnNum5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum5.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum5.Location = new System.Drawing.Point(139, 63);
            this.btnNum5.Name = "btnNum5";
            this.btnNum5.Size = new System.Drawing.Size(78, 56);
            this.btnNum5.TabIndex = 165;
            this.btnNum5.Text = "5";
            this.btnNum5.UseVisualStyleBackColor = false;
            this.btnNum5.Click += new System.EventHandler(this.btnNum5_Click);
            // 
            // btnNum2
            // 
            this.btnNum2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum2.FlatAppearance.BorderSize = 0;
            this.btnNum2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum2.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum2.Location = new System.Drawing.Point(139, 1);
            this.btnNum2.Name = "btnNum2";
            this.btnNum2.Size = new System.Drawing.Size(78, 56);
            this.btnNum2.TabIndex = 164;
            this.btnNum2.Text = "2";
            this.btnNum2.UseVisualStyleBackColor = false;
            this.btnNum2.Click += new System.EventHandler(this.btnNum2_Click);
            // 
            // btnBackSpace
            // 
            this.btnBackSpace.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnBackSpace.FlatAppearance.BorderSize = 0;
            this.btnBackSpace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackSpace.Font = new System.Drawing.Font("Trebuchet MS", 14.75F, System.Drawing.FontStyle.Bold);
            this.btnBackSpace.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnBackSpace.Image = ((System.Drawing.Image)(resources.GetObject("btnBackSpace.Image")));
            this.btnBackSpace.Location = new System.Drawing.Point(55, 247);
            this.btnBackSpace.Name = "btnBackSpace";
            this.btnBackSpace.Size = new System.Drawing.Size(246, 56);
            this.btnBackSpace.TabIndex = 171;
            this.btnBackSpace.UseVisualStyleBackColor = false;
            this.btnBackSpace.Click += new System.EventHandler(this.btnBackSpace_Click);
            // 
            // btnNum9
            // 
            this.btnNum9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum9.FlatAppearance.BorderSize = 0;
            this.btnNum9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum9.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum9.Location = new System.Drawing.Point(223, 125);
            this.btnNum9.Name = "btnNum9";
            this.btnNum9.Size = new System.Drawing.Size(78, 56);
            this.btnNum9.TabIndex = 170;
            this.btnNum9.Text = "9";
            this.btnNum9.UseVisualStyleBackColor = false;
            this.btnNum9.Click += new System.EventHandler(this.btnNum9_Click);
            // 
            // btnNum6
            // 
            this.btnNum6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum6.FlatAppearance.BorderSize = 0;
            this.btnNum6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum6.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum6.Location = new System.Drawing.Point(223, 63);
            this.btnNum6.Name = "btnNum6";
            this.btnNum6.Size = new System.Drawing.Size(78, 56);
            this.btnNum6.TabIndex = 169;
            this.btnNum6.Text = "6";
            this.btnNum6.UseVisualStyleBackColor = false;
            this.btnNum6.Click += new System.EventHandler(this.btnNum6_Click);
            // 
            // btnNum3
            // 
            this.btnNum3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnNum3.FlatAppearance.BorderSize = 0;
            this.btnNum3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNum3.Font = new System.Drawing.Font("Trebuchet MS", 20.75F, System.Drawing.FontStyle.Bold);
            this.btnNum3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnNum3.Location = new System.Drawing.Point(223, 1);
            this.btnNum3.Name = "btnNum3";
            this.btnNum3.Size = new System.Drawing.Size(78, 56);
            this.btnNum3.TabIndex = 168;
            this.btnNum3.Text = "3";
            this.btnNum3.UseVisualStyleBackColor = false;
            this.btnNum3.Click += new System.EventHandler(this.btnNum3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.Location = new System.Drawing.Point(223, 187);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 56);
            this.button1.TabIndex = 172;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Currency_Shortcuts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnBackSpace);
            this.Controls.Add(this.btnNum9);
            this.Controls.Add(this.btnNum6);
            this.Controls.Add(this.btnNum3);
            this.Controls.Add(this.btnNum0);
            this.Controls.Add(this.btnNum8);
            this.Controls.Add(this.btnNum5);
            this.Controls.Add(this.btnNum2);
            this.Controls.Add(this.btnDecimal);
            this.Controls.Add(this.btnNum7);
            this.Controls.Add(this.btnNum4);
            this.Controls.Add(this.btnNum1);
            this.Controls.Add(this.btnPaper100);
            this.Controls.Add(this.btnPaper50);
            this.Controls.Add(this.btnPaper20);
            this.Controls.Add(this.btnPaper10);
            this.Controls.Add(this.btnPaper5);
            this.Controls.Add(this.btnCoinTwo);
            this.Controls.Add(this.btnCoinOne);
            this.Name = "Currency_Shortcuts";
            this.Size = new System.Drawing.Size(346, 309);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCoinOne;
        private System.Windows.Forms.Button btnCoinTwo;
        private System.Windows.Forms.Button btnPaper5;
        private System.Windows.Forms.Button btnPaper10;
        private System.Windows.Forms.Button btnPaper20;
        private System.Windows.Forms.Button btnPaper50;
        private System.Windows.Forms.Button btnPaper100;
        private System.Windows.Forms.Button btnNum1;
        private System.Windows.Forms.Button btnNum4;
        private System.Windows.Forms.Button btnNum7;
        private System.Windows.Forms.Button btnDecimal;
        private System.Windows.Forms.Button btnNum0;
        private System.Windows.Forms.Button btnNum8;
        private System.Windows.Forms.Button btnNum5;
        private System.Windows.Forms.Button btnNum2;
        private System.Windows.Forms.Button btnBackSpace;
        private System.Windows.Forms.Button btnNum9;
        private System.Windows.Forms.Button btnNum6;
        private System.Windows.Forms.Button btnNum3;
        private System.Windows.Forms.Button button1;
    }
}
