﻿namespace supershop
{
    partial class Delete_Invoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Delete_Invoice));
            this.lblEmpID = new System.Windows.Forms.Label();
            this.dtgrdviewReturnItem = new System.Windows.Forms.DataGridView();
            this.lblMsg = new System.Windows.Forms.Label();
            this.txtbarcodeinputer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Suspen = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Calculator = new System.Windows.Forms.Button();
            this.ReturnSave = new System.Windows.Forms.Button();
            this.dtReturnDate = new System.Windows.Forms.DateTimePicker();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblDue = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblsalestime = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblShopid = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblPaidAmount = new System.Windows.Forms.Label();
            this.lblInvoiceNO = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lblsalesID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblpaytype = new System.Windows.Forms.Label();
            this.lblorderNO = new System.Windows.Forms.Label();
            this.chkWastage = new System.Windows.Forms.CheckBox();
            this.lblCustID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrdviewReturnItem)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblEmpID
            // 
            this.lblEmpID.AutoSize = true;
            this.lblEmpID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpID.Location = new System.Drawing.Point(46, 31);
            this.lblEmpID.Name = "lblEmpID";
            this.lblEmpID.Size = new System.Drawing.Size(42, 13);
            this.lblEmpID.TabIndex = 0;
            this.lblEmpID.Text = "=====";
            // 
            // dtgrdviewReturnItem
            // 
            this.dtgrdviewReturnItem.AllowUserToAddRows = false;
            this.dtgrdviewReturnItem.AllowUserToResizeRows = false;
            this.dtgrdviewReturnItem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgrdviewReturnItem.BackgroundColor = System.Drawing.Color.White;
            this.dtgrdviewReturnItem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Constantia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgrdviewReturnItem.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgrdviewReturnItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgrdviewReturnItem.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgrdviewReturnItem.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dtgrdviewReturnItem.Location = new System.Drawing.Point(68, 119);
            this.dtgrdviewReturnItem.Name = "dtgrdviewReturnItem";
            this.dtgrdviewReturnItem.RowHeadersVisible = false;
            this.dtgrdviewReturnItem.RowTemplate.Height = 30;
            this.dtgrdviewReturnItem.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgrdviewReturnItem.Size = new System.Drawing.Size(598, 459);
            this.dtgrdviewReturnItem.TabIndex = 144;
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Location = new System.Drawing.Point(362, 65);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(52, 13);
            this.lblMsg.TabIndex = 143;
            this.lblMsg.Text = "not found";
            this.lblMsg.Visible = false;
            // 
            // txtbarcodeinputer
            // 
            this.txtbarcodeinputer.BackColor = System.Drawing.SystemColors.Menu;
            this.txtbarcodeinputer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbarcodeinputer.Location = new System.Drawing.Point(68, 89);
            this.txtbarcodeinputer.Name = "txtbarcodeinputer";
            this.txtbarcodeinputer.Size = new System.Drawing.Size(419, 22);
            this.txtbarcodeinputer.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtbarcodeinputer, "Insert Invoice number / Receipt number");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(64, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(274, 21);
            this.label2.TabIndex = 142;
            this.label2.Text = "Insert Sold Invoice no :";
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 800;
            this.toolTip1.AutoPopDelay = 80000;
            this.toolTip1.BackColor = System.Drawing.Color.OliveDrab;
            this.toolTip1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.toolTip1.InitialDelay = 10;
            this.toolTip1.ReshowDelay = 10;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // Suspen
            // 
            this.Suspen.BackColor = System.Drawing.Color.White;
            this.Suspen.FlatAppearance.BorderSize = 0;
            this.Suspen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Suspen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Suspen.ForeColor = System.Drawing.Color.Blue;
            this.Suspen.Image = ((System.Drawing.Image)(resources.GetObject("Suspen.Image")));
            this.Suspen.Location = new System.Drawing.Point(865, 518);
            this.Suspen.Name = "Suspen";
            this.Suspen.Size = new System.Drawing.Size(149, 60);
            this.Suspen.TabIndex = 4;
            this.Suspen.Text = "Suspend";
            this.Suspen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTip1.SetToolTip(this.Suspen, "Press For Cancel Transaction");
            this.Suspen.UseVisualStyleBackColor = false;
            this.Suspen.Visible = false;
            this.Suspen.Click += new System.EventHandler(this.Suspen_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 22);
            this.label6.TabIndex = 147;
            this.label6.Text = "Delete Invoice";
            // 
            // Calculator
            // 
            this.Calculator.BackColor = System.Drawing.Color.White;
            this.Calculator.FlatAppearance.BorderSize = 0;
            this.Calculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Calculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculator.ForeColor = System.Drawing.Color.Navy;
            this.Calculator.Image = ((System.Drawing.Image)(resources.GetObject("Calculator.Image")));
            this.Calculator.Location = new System.Drawing.Point(717, 517);
            this.Calculator.Name = "Calculator";
            this.Calculator.Size = new System.Drawing.Size(99, 61);
            this.Calculator.TabIndex = 5;
            this.Calculator.Text = "Calculator";
            this.Calculator.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Calculator.UseVisualStyleBackColor = false;
            this.Calculator.Click += new System.EventHandler(this.button11_Click);
            // 
            // ReturnSave
            // 
            this.ReturnSave.BackColor = System.Drawing.Color.Red;
            this.ReturnSave.FlatAppearance.BorderSize = 0;
            this.ReturnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReturnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.75F, System.Drawing.FontStyle.Bold);
            this.ReturnSave.ForeColor = System.Drawing.Color.Linen;
            this.ReturnSave.Location = new System.Drawing.Point(694, 460);
            this.ReturnSave.Name = "ReturnSave";
            this.ReturnSave.Size = new System.Drawing.Size(338, 39);
            this.ReturnSave.TabIndex = 3;
            this.ReturnSave.Text = "Delete Invoice";
            this.ReturnSave.UseVisualStyleBackColor = false;
            this.ReturnSave.Click += new System.EventHandler(this.ReturnSave_Click);
            // 
            // dtReturnDate
            // 
            this.dtReturnDate.CustomFormat = "";
            this.dtReturnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtReturnDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtReturnDate.Location = new System.Drawing.Point(694, 9);
            this.dtReturnDate.Name = "dtReturnDate";
            this.dtReturnDate.Size = new System.Drawing.Size(289, 21);
            this.dtReturnDate.TabIndex = 148;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btnSubmit.Location = new System.Drawing.Point(493, 88);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(84, 24);
            this.btnSubmit.TabIndex = 151;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblDue
            // 
            this.lblDue.AutoSize = true;
            this.lblDue.Location = new System.Drawing.Point(146, 192);
            this.lblDue.Name = "lblDue";
            this.lblDue.Size = new System.Drawing.Size(15, 16);
            this.lblDue.TabIndex = 159;
            this.lblDue.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 192);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 16);
            this.label7.TabIndex = 160;
            this.label7.Text = "Due:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 16);
            this.label8.TabIndex = 162;
            this.label8.Text = "Change:";
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Location = new System.Drawing.Point(146, 164);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(15, 16);
            this.lblChange.TabIndex = 161;
            this.lblChange.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(20, 85);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 16);
            this.label14.TabIndex = 164;
            this.label14.Text = "Sales Time:";
            // 
            // lblsalestime
            // 
            this.lblsalestime.AutoSize = true;
            this.lblsalestime.Location = new System.Drawing.Point(146, 85);
            this.lblsalestime.Name = "lblsalestime";
            this.lblsalestime.Size = new System.Drawing.Size(12, 16);
            this.lblsalestime.TabIndex = 163;
            this.lblsalestime.Text = "-";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(20, 216);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 16);
            this.label15.TabIndex = 168;
            this.label15.Text = "ShopID:";
            // 
            // lblShopid
            // 
            this.lblShopid.AutoSize = true;
            this.lblShopid.Location = new System.Drawing.Point(146, 216);
            this.lblShopid.Name = "lblShopid";
            this.lblShopid.Size = new System.Drawing.Size(12, 16);
            this.lblShopid.TabIndex = 167;
            this.lblShopid.Text = "-";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(20, 139);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(87, 16);
            this.label22.TabIndex = 174;
            this.label22.Text = "Paid Amount:";
            // 
            // lblPaidAmount
            // 
            this.lblPaidAmount.AutoSize = true;
            this.lblPaidAmount.Location = new System.Drawing.Point(146, 139);
            this.lblPaidAmount.Name = "lblPaidAmount";
            this.lblPaidAmount.Size = new System.Drawing.Size(15, 16);
            this.lblPaidAmount.TabIndex = 173;
            this.lblPaidAmount.Text = "0";
            // 
            // lblInvoiceNO
            // 
            this.lblInvoiceNO.AutoSize = true;
            this.lblInvoiceNO.Location = new System.Drawing.Point(146, 55);
            this.lblInvoiceNO.Name = "lblInvoiceNO";
            this.lblInvoiceNO.Size = new System.Drawing.Size(12, 16);
            this.lblInvoiceNO.TabIndex = 178;
            this.lblInvoiceNO.Text = "-";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(20, 55);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 16);
            this.label25.TabIndex = 177;
            this.label25.Text = "Invoice NO:";
            // 
            // lblsalesID
            // 
            this.lblsalesID.AutoSize = true;
            this.lblsalesID.Location = new System.Drawing.Point(965, 70);
            this.lblsalesID.Name = "lblsalesID";
            this.lblsalesID.Size = new System.Drawing.Size(10, 13);
            this.lblsalesID.TabIndex = 176;
            this.lblsalesID.Text = "-";
            this.lblsalesID.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(910, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 175;
            this.label1.Text = "Sales ID:";
            this.label1.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 111);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 16);
            this.label20.TabIndex = 172;
            this.label20.Text = "Payment Tye:";
            // 
            // lblpaytype
            // 
            this.lblpaytype.AutoSize = true;
            this.lblpaytype.Location = new System.Drawing.Point(146, 111);
            this.lblpaytype.Name = "lblpaytype";
            this.lblpaytype.Size = new System.Drawing.Size(12, 16);
            this.lblpaytype.TabIndex = 171;
            this.lblpaytype.Text = "-";
            // 
            // lblorderNO
            // 
            this.lblorderNO.AutoSize = true;
            this.lblorderNO.Location = new System.Drawing.Point(447, 15);
            this.lblorderNO.Name = "lblorderNO";
            this.lblorderNO.Size = new System.Drawing.Size(10, 13);
            this.lblorderNO.TabIndex = 172;
            this.lblorderNO.Text = "-";
            // 
            // chkWastage
            // 
            this.chkWastage.AutoSize = true;
            this.chkWastage.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkWastage.Location = new System.Drawing.Point(594, 93);
            this.chkWastage.Name = "chkWastage";
            this.chkWastage.Size = new System.Drawing.Size(69, 17);
            this.chkWastage.TabIndex = 174;
            this.chkWastage.Text = "Wastage";
            this.chkWastage.UseVisualStyleBackColor = true;
            // 
            // lblCustID
            // 
            this.lblCustID.AutoSize = true;
            this.lblCustID.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.75F);
            this.lblCustID.Location = new System.Drawing.Point(114, 15);
            this.lblCustID.Name = "lblCustID";
            this.lblCustID.Size = new System.Drawing.Size(37, 9);
            this.lblCustID.TabIndex = 104;
            this.lblCustID.Text = "10000009";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 16);
            this.label4.TabIndex = 105;
            this.label4.Text = "Customer  :";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F);
            this.lblCustomerName.Location = new System.Drawing.Point(146, 33);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(10, 13);
            this.lblCustomerName.TabIndex = 174;
            this.lblCustomerName.Text = "-";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Orange;
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.lblPaidAmount);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.lblShopid);
            this.groupBox1.Controls.Add(this.lblChange);
            this.groupBox1.Controls.Add(this.lblInvoiceNO);
            this.groupBox1.Controls.Add(this.lblCustomerName);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.lblpaytype);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblCustID);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.lblDue);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.lblsalestime);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(694, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(338, 353);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "invoice Detail";
            // 
            // Delete_Invoice
            // 
            this.AcceptButton = this.btnSubmit;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1057, 683);
            this.Controls.Add(this.lblsalesID);
            this.Controls.Add(this.chkWastage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblorderNO);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.dtReturnDate);
            this.Controls.Add(this.Calculator);
            this.Controls.Add(this.Suspen);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ReturnSave);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtgrdviewReturnItem);
            this.Controls.Add(this.lblEmpID);
            this.Controls.Add(this.txtbarcodeinputer);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.label2);
            this.Name = "Delete_Invoice";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Delete Invoice";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Delete_Invoice_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgrdviewReturnItem)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmpID;
        private System.Windows.Forms.DataGridView dtgrdviewReturnItem;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.TextBox txtbarcodeinputer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Calculator;
        private System.Windows.Forms.Button Suspen;
        private System.Windows.Forms.Button ReturnSave;
        private System.Windows.Forms.DateTimePicker dtReturnDate;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblDue;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblsalestime;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblShopid;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblpaytype;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblPaidAmount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblsalesID;
        private System.Windows.Forms.Label lblorderNO;
        private System.Windows.Forms.CheckBox chkWastage;
        private System.Windows.Forms.Label lblInvoiceNO;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblCustID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}