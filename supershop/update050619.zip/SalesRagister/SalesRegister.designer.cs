﻿namespace supershop
{
    partial class SalesRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SalesRegister));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ItemcartPanel = new System.Windows.Forms.Panel();
            this.dgrvSalesItemList = new System.Windows.Forms.DataGridView();
            this.lblOrderway = new System.Windows.Forms.Label();
            this.txtInvoice = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnBooking = new System.Windows.Forms.Button();
            this.linkbtnSlpit = new System.Windows.Forms.LinkLabel();
            this.comboTable = new System.Windows.Forms.ComboBox();
            this.btnCOD = new System.Windows.Forms.Button();
            this.btnDraft = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCashAndPrint = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.labelTotal = new System.Windows.Forms.Label();
            this.labelDiscount = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtDiscountRate = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.labelChangeamount = new System.Windows.Forms.Label();
            this.labelCashReceived = new System.Windows.Forms.Label();
            this.lblDeliveryChargis = new System.Windows.Forms.Label();
            this.labelSubTotal = new System.Windows.Forms.Label();
            this.lblTotalPayable = new System.Windows.Forms.Label();
            this.labelDeliveryCharge = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtcashRecived = new System.Windows.Forms.TextBox();
            this.lblChangeAmt = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lbloveralldiscount = new System.Windows.Forms.TextBox();
            this.btnSalesCredit = new System.Windows.Forms.Button();
            this.btnSuspend = new System.Windows.Forms.Button();
            this.lblsubtotal = new System.Windows.Forms.Label();
            this.lblInvoiceNO = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.ComboCustID = new System.Windows.Forms.ComboBox();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.txtDueAmount = new System.Windows.Forms.TextBox();
            this.txtPaidAmount = new System.Windows.Forms.TextBox();
            this.txtChangeAmount = new System.Windows.Forms.TextBox();
            this.CombPayby = new System.Windows.Forms.ComboBox();
            this.txtReffrance = new System.Windows.Forms.TextBox();
            this.PanelCategoryList = new System.Windows.Forms.Panel();
            this.flwLyoutCategoryPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.btnback = new System.Windows.Forms.Button();
            this.btnSaveOnly = new System.Windows.Forms.Button();
            this.btnCompleteSalesAndPrint = new System.Windows.Forms.Button();
            this.btnSaveSplit = new System.Windows.Forms.Button();
            this.btnSplitPrint = new System.Windows.Forms.Button();
            this.txtSearchItem = new System.Windows.Forms.TextBox();
            this.txtBarcodeReaderBox = new System.Windows.Forms.TextBox();
            this.currency_Shortcuts1 = new supershop.SalesRagister.Currency_Shortcuts();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.helplnk = new System.Windows.Forms.LinkLabel();
            this.linkLabelCalculator = new System.Windows.Forms.LinkLabel();
            this.tabSRcontrol = new System.Windows.Forms.TabControl();
            this.tabPageSR_Counter = new System.Windows.Forms.TabPage();
            this.lblmainCustwalletant = new System.Windows.Forms.Label();
            this.lblDeliverydate = new System.Windows.Forms.Label();
            this.dtsaleDeliveryDate = new System.Windows.Forms.DateTimePicker();
            this.lblIsReciepe = new System.Windows.Forms.Label();
            this.lblSerialize = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.chkbutton = new System.Windows.Forms.CheckBox();
            this.chkWithGrid = new System.Windows.Forms.CheckBox();
            this.btnSerchItem = new System.Windows.Forms.Button();
            this.chkoutput = new System.Windows.Forms.CheckBox();
            this.chkImage = new System.Windows.Forms.CheckBox();
            this.itemCount = new System.Windows.Forms.Label();
            this.lblCatagory = new System.Windows.Forms.Label();
            this.labelSearchItems = new System.Windows.Forms.Label();
            this.lblInsertitembarcode = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.radiocredit = new System.Windows.Forms.RadioButton();
            this.radioCash = new System.Windows.Forms.RadioButton();
            this.dtsaleDate = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.lblstart = new System.Windows.Forms.Label();
            this.lblPerishable = new System.Windows.Forms.Label();
            this.lblorderNO = new System.Windows.Forms.Label();
            this.linkLabelRefresh = new System.Windows.Forms.LinkLabel();
            this.labelCustomerName = new System.Windows.Forms.Label();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ItemButton = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.flowLayoutPanelItemListButton = new System.Windows.Forms.FlowLayoutPanel();
            this.ItemGrid = new System.Windows.Forms.TabPage();
            this.PanelStockList1 = new System.Windows.Forms.Panel();
            this.dgrvProductList = new System.Windows.Forms.DataGridView();
            this.ItemsImage = new System.Windows.Forms.TabPage();
            this.PanelStockList = new System.Windows.Forms.Panel();
            this.flowLayoutPanelItemList = new System.Windows.Forms.FlowLayoutPanel();
            this.RelatedItems = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.PenalRelateditems = new System.Windows.Forms.FlowLayoutPanel();
            this.Catagories = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PanelCatagories = new System.Windows.Forms.FlowLayoutPanel();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.comboSalesMan = new System.Windows.Forms.ComboBox();
            this.tabPageSR_Payment = new System.Windows.Forms.TabPage();
            this.lblCustAvailableAmt = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnAppGridAdd = new System.Windows.Forms.Button();
            this.lnkCustomer = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.chkCreditTrans = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtInvoicePAY = new System.Windows.Forms.TextBox();
            this.lblInvoiceNOPAY = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.labelReffranceNo = new System.Windows.Forms.Label();
            this.lblPaid = new System.Windows.Forms.Label();
            this.GridPayment = new System.Windows.Forms.DataGridView();
            this.linkLabelAddNew = new System.Windows.Forms.LinkLabel();
            this.lblTotalpayableAmtPY = new System.Windows.Forms.Label();
            this.label1TotalPayable = new System.Windows.Forms.Label();
            this.labelShortcuts = new System.Windows.Forms.Label();
            this.lblCustID = new System.Windows.Forms.Label();
            this.labelInsertCustomeramount = new System.Windows.Forms.Label();
            this.label1Optional = new System.Windows.Forms.Label();
            this.labelComment = new System.Windows.Forms.Label();
            this.labelDue = new System.Windows.Forms.Label();
            this.label1ChangeAmount = new System.Windows.Forms.Label();
            this.labelPaidAmount = new System.Windows.Forms.Label();
            this.labelPayby = new System.Windows.Forms.Label();
            this.labelSalesDate = new System.Windows.Forms.Label();
            this.dtSalesDate = new System.Windows.Forms.DateTimePicker();
            this.RefrashPayby = new System.Windows.Forms.Button();
            this.btnrefrash = new System.Windows.Forms.Button();
            this.tabPageSR_Split_Bill = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.btnAmountsplit = new System.Windows.Forms.Button();
            this.btnItemSplit = new System.Windows.Forms.Button();
            this.lblPaid1 = new System.Windows.Forms.Label();
            this.lblTotalPayment = new System.Windows.Forms.Label();
            this.lblMaxNOBill = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btnSave = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.comboPaytype = new System.Windows.Forms.ComboBox();
            this.txtSplitReffrance = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ComboSplitCustomer = new System.Windows.Forms.ComboBox();
            this.textSlpitAmt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textSlpitNO = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridPaymentSplit = new System.Windows.Forms.DataGridView();
            this.tabCashier = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnCustCode = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSearchCustCode = new System.Windows.Forms.TextBox();
            this.txtCas = new System.Windows.Forms.TextBox();
            this.chkdiscredit = new System.Windows.Forms.CheckBox();
            this.btnSerchCashier = new System.Windows.Forms.Button();
            this.lblMsg = new System.Windows.Forms.Label();
            this.btnCashierRefresh = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInvoiceCash = new System.Windows.Forms.TextBox();
            this.dtStartDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.datagrdReportDetails = new System.Windows.Forms.DataGridView();
            this.tabDelivery = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.dtDriverStartDate = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.txtReciptNO = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtGrdvOrderDetails = new System.Windows.Forms.DataGridView();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.MyPrintPreviewDialog = new System.Windows.Forms.PageSetupDialog();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenu_Sales = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.reAssignDriverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblClear = new System.Windows.Forms.Label();
            this.lblDraft = new System.Windows.Forms.Label();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.addSaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.lblCustomerPage = new System.Windows.Forms.Label();
            this.lblIsCustAdvanceAmtYN = new System.Windows.Forms.Label();
            this.lblCustPage4Cashier = new System.Windows.Forms.Label();
            this.ItemcartPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvSalesItemList)).BeginInit();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel10.SuspendLayout();
            this.PanelCategoryList.SuspendLayout();
            this.tabSRcontrol.SuspendLayout();
            this.tabPageSR_Counter.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.ItemButton.SuspendLayout();
            this.panel9.SuspendLayout();
            this.ItemGrid.SuspendLayout();
            this.PanelStockList1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvProductList)).BeginInit();
            this.ItemsImage.SuspendLayout();
            this.PanelStockList.SuspendLayout();
            this.RelatedItems.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Catagories.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPageSR_Payment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridPayment)).BeginInit();
            this.tabPageSR_Split_Bill.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPaymentSplit)).BeginInit();
            this.tabCashier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrdReportDetails)).BeginInit();
            this.tabDelivery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdvOrderDetails)).BeginInit();
            this.contextMenu_Sales.SuspendLayout();
            this.SuspendLayout();
            // 
            // ItemcartPanel
            // 
            this.ItemcartPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ItemcartPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ItemcartPanel.Controls.Add(this.dgrvSalesItemList);
            this.ItemcartPanel.Controls.Add(this.lblOrderway);
            this.ItemcartPanel.Location = new System.Drawing.Point(6, 91);
            this.ItemcartPanel.Name = "ItemcartPanel";
            this.ItemcartPanel.Size = new System.Drawing.Size(467, 395);
            this.ItemcartPanel.TabIndex = 145;
            // 
            // dgrvSalesItemList
            // 
            this.dgrvSalesItemList.AllowUserToAddRows = false;
            this.dgrvSalesItemList.AllowUserToResizeRows = false;
            this.dgrvSalesItemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgrvSalesItemList.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgrvSalesItemList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Constantia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrvSalesItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgrvSalesItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrvSalesItemList.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgrvSalesItemList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgrvSalesItemList.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dgrvSalesItemList.Location = new System.Drawing.Point(0, 0);
            this.dgrvSalesItemList.Name = "dgrvSalesItemList";
            this.dgrvSalesItemList.RowHeadersVisible = false;
            this.dgrvSalesItemList.RowTemplate.Height = 30;
            this.dgrvSalesItemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrvSalesItemList.Size = new System.Drawing.Size(465, 393);
            this.dgrvSalesItemList.TabIndex = 94;
            this.dgrvSalesItemList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvSalesItemList_CellClick);
            this.dgrvSalesItemList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvSalesItemList_CellContentClick);
            this.dgrvSalesItemList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvSalesItemList_CellEndEdit);
            this.dgrvSalesItemList.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvSalesItemList_CellValueChanged);
            // 
            // lblOrderway
            // 
            this.lblOrderway.AutoSize = true;
            this.lblOrderway.Font = new System.Drawing.Font("Trebuchet MS", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderway.Location = new System.Drawing.Point(326, -1);
            this.lblOrderway.Name = "lblOrderway";
            this.lblOrderway.Size = new System.Drawing.Size(76, 18);
            this.lblOrderway.TabIndex = 162;
            this.lblOrderway.Text = "Order way :";
            // 
            // txtInvoice
            // 
            this.txtInvoice.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtInvoice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInvoice.Enabled = false;
            this.txtInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInvoice.Location = new System.Drawing.Point(836, 605);
            this.txtInvoice.Name = "txtInvoice";
            this.txtInvoice.Size = new System.Drawing.Size(50, 8);
            this.txtInvoice.TabIndex = 154;
            this.txtInvoice.Text = "1";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Info;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnBooking);
            this.panel3.Controls.Add(this.linkbtnSlpit);
            this.panel3.Controls.Add(this.comboTable);
            this.panel3.Controls.Add(this.btnCOD);
            this.panel3.Controls.Add(this.btnDraft);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.btnCashAndPrint);
            this.panel3.Controls.Add(this.tableLayoutPanel1);
            this.panel3.Controls.Add(this.btnSalesCredit);
            this.panel3.Controls.Add(this.btnSuspend);
            this.panel3.Location = new System.Drawing.Point(6, 491);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(467, 128);
            this.panel3.TabIndex = 149;
            // 
            // btnBooking
            // 
            this.btnBooking.BackColor = System.Drawing.Color.Orange;
            this.btnBooking.FlatAppearance.BorderSize = 0;
            this.btnBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBooking.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBooking.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.btnBooking.Image = ((System.Drawing.Image)(resources.GetObject("btnBooking.Image")));
            this.btnBooking.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBooking.Location = new System.Drawing.Point(5, 30);
            this.btnBooking.Name = "btnBooking";
            this.btnBooking.Size = new System.Drawing.Size(95, 59);
            this.btnBooking.TabIndex = 178;
            this.btnBooking.Text = "Booking";
            this.btnBooking.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btnBooking, "Cash On Delivery");
            this.btnBooking.UseVisualStyleBackColor = false;
            this.btnBooking.Click += new System.EventHandler(this.btnBooking_Click);
            // 
            // linkbtnSlpit
            // 
            this.linkbtnSlpit.AutoSize = true;
            this.linkbtnSlpit.Location = new System.Drawing.Point(189, 8);
            this.linkbtnSlpit.Name = "linkbtnSlpit";
            this.linkbtnSlpit.Size = new System.Drawing.Size(43, 13);
            this.linkbtnSlpit.TabIndex = 176;
            this.linkbtnSlpit.TabStop = true;
            this.linkbtnSlpit.Text = "Split Bill";
            this.linkbtnSlpit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkbtnSlpit_LinkClicked);
            // 
            // comboTable
            // 
            this.comboTable.FormattingEnabled = true;
            this.comboTable.Items.AddRange(new object[] {
            "Walk In",
            "Salesman name",
            "Foodiz"});
            this.comboTable.Location = new System.Drawing.Point(47, 3);
            this.comboTable.Name = "comboTable";
            this.comboTable.Size = new System.Drawing.Size(130, 21);
            this.comboTable.TabIndex = 177;
            // 
            // btnCOD
            // 
            this.btnCOD.BackColor = System.Drawing.Color.PaleGreen;
            this.btnCOD.FlatAppearance.BorderSize = 0;
            this.btnCOD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCOD.Font = new System.Drawing.Font("Trebuchet MS", 10.75F, System.Drawing.FontStyle.Bold);
            this.btnCOD.ForeColor = System.Drawing.Color.Green;
            this.btnCOD.Image = ((System.Drawing.Image)(resources.GetObject("btnCOD.Image")));
            this.btnCOD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCOD.Location = new System.Drawing.Point(74, 95);
            this.btnCOD.Name = "btnCOD";
            this.btnCOD.Size = new System.Drawing.Size(92, 25);
            this.btnCOD.TabIndex = 173;
            this.btnCOD.Text = "COD    ";
            this.btnCOD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btnCOD, "Cash On Delivery");
            this.btnCOD.UseVisualStyleBackColor = false;
            this.btnCOD.Click += new System.EventHandler(this.btnCOD_Click);
            // 
            // btnDraft
            // 
            this.btnDraft.BackColor = System.Drawing.Color.Gold;
            this.btnDraft.FlatAppearance.BorderSize = 0;
            this.btnDraft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDraft.Font = new System.Drawing.Font("Trebuchet MS", 10.75F, System.Drawing.FontStyle.Bold);
            this.btnDraft.ForeColor = System.Drawing.Color.Green;
            this.btnDraft.Location = new System.Drawing.Point(173, 94);
            this.btnDraft.Name = "btnDraft";
            this.btnDraft.Size = new System.Drawing.Size(59, 25);
            this.btnDraft.TabIndex = 172;
            this.btnDraft.Text = "Draft";
            this.toolTip1.SetToolTip(this.btnDraft, "Draft");
            this.btnDraft.UseVisualStyleBackColor = false;
            this.btnDraft.Click += new System.EventHandler(this.btnDraft_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(0, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 18);
            this.label5.TabIndex = 176;
            this.label5.Text = "Table :";
            // 
            // btnCashAndPrint
            // 
            this.btnCashAndPrint.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnCashAndPrint.FlatAppearance.BorderSize = 0;
            this.btnCashAndPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCashAndPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnCashAndPrint.ForeColor = System.Drawing.Color.Yellow;
            this.btnCashAndPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnCashAndPrint.Image")));
            this.btnCashAndPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCashAndPrint.Location = new System.Drawing.Point(106, 29);
            this.btnCashAndPrint.Name = "btnCashAndPrint";
            this.btnCashAndPrint.Size = new System.Drawing.Size(126, 28);
            this.btnCashAndPrint.TabIndex = 169;
            this.btnCashAndPrint.Text = "Cash / Print";
            this.btnCashAndPrint.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btnCashAndPrint, "Cash and  print receipt");
            this.btnCashAndPrint.UseVisualStyleBackColor = false;
            this.btnCashAndPrint.Click += new System.EventHandler(this.btnCashAndPrint_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.GreenYellow;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.labelTotal, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelDiscount, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblTotal, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelChangeamount, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelCashReceived, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblDeliveryChargis, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelSubTotal, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblTotalPayable, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelDeliveryCharge, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblChangeAmt, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 1, 1);
            this.tableLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(238, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.33898F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.25424F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(225, 119);
            this.tableLayoutPanel1.TabIndex = 165;
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelTotal.Location = new System.Drawing.Point(2, 1);
            this.labelTotal.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(62, 18);
            this.labelTotal.TabIndex = 123;
            this.labelTotal.Text = "Total:";
            // 
            // labelDiscount
            // 
            this.labelDiscount.AutoSize = true;
            this.labelDiscount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDiscount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelDiscount.Location = new System.Drawing.Point(2, 20);
            this.labelDiscount.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.labelDiscount.Name = "labelDiscount";
            this.labelDiscount.Size = new System.Drawing.Size(62, 18);
            this.labelDiscount.TabIndex = 132;
            this.labelDiscount.Text = "Discount:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.White;
            this.lblTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotal.Location = new System.Drawing.Point(71, 1);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(60, 18);
            this.lblTotal.TabIndex = 133;
            this.lblTotal.Text = "00.00";
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(138, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(83, 12);
            this.panel4.TabIndex = 164;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtDiscountRate);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(138, 23);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(83, 12);
            this.panel5.TabIndex = 165;
            // 
            // txtDiscountRate
            // 
            this.txtDiscountRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtDiscountRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiscountRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscountRate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtDiscountRate.Location = new System.Drawing.Point(3, -1);
            this.txtDiscountRate.Name = "txtDiscountRate";
            this.txtDiscountRate.Size = new System.Drawing.Size(54, 13);
            this.txtDiscountRate.TabIndex = 2;
            this.txtDiscountRate.Text = "0";
            this.toolTip1.SetToolTip(this.txtDiscountRate, "Insert Over all Discount Rate.\r\nDiscount Rate Apply with Sub total");
            this.txtDiscountRate.TextChanged += new System.EventHandler(this.txtDiscountRate_TextChanged);
            this.txtDiscountRate.Enter += new System.EventHandler(this.txtDiscountRate_Enter);
            this.txtDiscountRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiscountRate_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(63, -3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 15);
            this.label13.TabIndex = 102;
            this.label13.Text = "%";
            // 
            // labelChangeamount
            // 
            this.labelChangeamount.AutoSize = true;
            this.labelChangeamount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelChangeamount.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelChangeamount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelChangeamount.Location = new System.Drawing.Point(2, 100);
            this.labelChangeamount.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.labelChangeamount.Name = "labelChangeamount";
            this.labelChangeamount.Size = new System.Drawing.Size(62, 18);
            this.labelChangeamount.TabIndex = 170;
            this.labelChangeamount.Text = "Change amount:";
            // 
            // labelCashReceived
            // 
            this.labelCashReceived.AutoSize = true;
            this.labelCashReceived.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelCashReceived.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCashReceived.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelCashReceived.Location = new System.Drawing.Point(2, 77);
            this.labelCashReceived.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.labelCashReceived.Name = "labelCashReceived";
            this.labelCashReceived.Size = new System.Drawing.Size(62, 22);
            this.labelCashReceived.TabIndex = 168;
            this.labelCashReceived.Text = "Cash Receive";
            this.toolTip1.SetToolTip(this.labelCashReceived, "Cash Received:");
            // 
            // lblDeliveryChargis
            // 
            this.lblDeliveryChargis.AutoSize = true;
            this.lblDeliveryChargis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeliveryChargis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeliveryChargis.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblDeliveryChargis.Location = new System.Drawing.Point(71, 39);
            this.lblDeliveryChargis.Name = "lblDeliveryChargis";
            this.lblDeliveryChargis.Size = new System.Drawing.Size(60, 18);
            this.lblDeliveryChargis.TabIndex = 163;
            this.lblDeliveryChargis.Text = "0";
            this.toolTip1.SetToolTip(this.lblDeliveryChargis, "Total Tax");
            // 
            // labelSubTotal
            // 
            this.labelSubTotal.AutoSize = true;
            this.labelSubTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSubTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelSubTotal.Location = new System.Drawing.Point(2, 58);
            this.labelSubTotal.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.labelSubTotal.Name = "labelSubTotal";
            this.labelSubTotal.Size = new System.Drawing.Size(62, 18);
            this.labelSubTotal.TabIndex = 140;
            this.labelSubTotal.Text = "Sub Total :";
            // 
            // lblTotalPayable
            // 
            this.lblTotalPayable.AutoSize = true;
            this.lblTotalPayable.BackColor = System.Drawing.Color.White;
            this.lblTotalPayable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalPayable.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPayable.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotalPayable.Location = new System.Drawing.Point(71, 58);
            this.lblTotalPayable.Name = "lblTotalPayable";
            this.lblTotalPayable.Size = new System.Drawing.Size(60, 18);
            this.lblTotalPayable.TabIndex = 134;
            this.lblTotalPayable.Text = "00";
            this.lblTotalPayable.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelDeliveryCharge
            // 
            this.labelDeliveryCharge.AutoSize = true;
            this.labelDeliveryCharge.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelDeliveryCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDeliveryCharge.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelDeliveryCharge.Location = new System.Drawing.Point(2, 39);
            this.labelDeliveryCharge.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.labelDeliveryCharge.Name = "labelDeliveryCharge";
            this.labelDeliveryCharge.Size = new System.Drawing.Size(62, 18);
            this.labelDeliveryCharge.TabIndex = 162;
            this.labelDeliveryCharge.Text = "Delivery";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtcashRecived);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(71, 80);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(60, 16);
            this.panel6.TabIndex = 172;
            // 
            // txtcashRecived
            // 
            this.txtcashRecived.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtcashRecived.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcashRecived.Location = new System.Drawing.Point(0, 0);
            this.txtcashRecived.Margin = new System.Windows.Forms.Padding(0);
            this.txtcashRecived.Name = "txtcashRecived";
            this.txtcashRecived.Size = new System.Drawing.Size(60, 20);
            this.txtcashRecived.TabIndex = 167;
            this.txtcashRecived.TextChanged += new System.EventHandler(this.txtcashRecived_TextChanged);
            this.txtcashRecived.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcashRecived_KeyPress);
            this.txtcashRecived.Leave += new System.EventHandler(this.txtcashRecived_Leave);
            // 
            // lblChangeAmt
            // 
            this.lblChangeAmt.AutoSize = true;
            this.lblChangeAmt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblChangeAmt.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeAmt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblChangeAmt.Location = new System.Drawing.Point(71, 100);
            this.lblChangeAmt.Name = "lblChangeAmt";
            this.lblChangeAmt.Size = new System.Drawing.Size(60, 18);
            this.lblChangeAmt.TabIndex = 171;
            this.lblChangeAmt.Text = "0";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.lbloveralldiscount);
            this.panel10.Location = new System.Drawing.Point(71, 23);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(60, 11);
            this.panel10.TabIndex = 173;
            // 
            // lbloveralldiscount
            // 
            this.lbloveralldiscount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lbloveralldiscount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbloveralldiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloveralldiscount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbloveralldiscount.Location = new System.Drawing.Point(3, -1);
            this.lbloveralldiscount.Name = "lbloveralldiscount";
            this.lbloveralldiscount.Size = new System.Drawing.Size(56, 13);
            this.lbloveralldiscount.TabIndex = 164;
            this.lbloveralldiscount.Text = "0";
            this.toolTip1.SetToolTip(this.lbloveralldiscount, "Insert Over all Discount Rate.\r\nDiscount Rate Apply with Sub total");
            this.lbloveralldiscount.Enter += new System.EventHandler(this.lbloveralldiscount_Enter);
            this.lbloveralldiscount.Leave += new System.EventHandler(this.lbloveralldiscount_Leave);
            // 
            // btnSalesCredit
            // 
            this.btnSalesCredit.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSalesCredit.Enabled = false;
            this.btnSalesCredit.FlatAppearance.BorderSize = 0;
            this.btnSalesCredit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalesCredit.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.btnSalesCredit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnSalesCredit.Image = ((System.Drawing.Image)(resources.GetObject("btnSalesCredit.Image")));
            this.btnSalesCredit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalesCredit.Location = new System.Drawing.Point(106, 63);
            this.btnSalesCredit.Name = "btnSalesCredit";
            this.btnSalesCredit.Size = new System.Drawing.Size(126, 27);
            this.btnSalesCredit.TabIndex = 164;
            this.btnSalesCredit.Text = "Payment";
            this.btnSalesCredit.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.toolTip1.SetToolTip(this.btnSalesCredit, "Receive Customer amount");
            this.btnSalesCredit.UseVisualStyleBackColor = false;
            this.btnSalesCredit.Click += new System.EventHandler(this.btnSalesCredit_Click);
            // 
            // btnSuspend
            // 
            this.btnSuspend.BackColor = System.Drawing.Color.OrangeRed;
            this.btnSuspend.Enabled = false;
            this.btnSuspend.FlatAppearance.BorderSize = 0;
            this.btnSuspend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuspend.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuspend.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnSuspend.Location = new System.Drawing.Point(5, 95);
            this.btnSuspend.Name = "btnSuspend";
            this.btnSuspend.Size = new System.Drawing.Size(65, 25);
            this.btnSuspend.TabIndex = 153;
            this.btnSuspend.Text = "Cancel";
            this.btnSuspend.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnSuspend, "Shift+S");
            this.btnSuspend.UseVisualStyleBackColor = false;
            this.btnSuspend.Click += new System.EventHandler(this.btnSuspend_Click);
            // 
            // lblsubtotal
            // 
            this.lblsubtotal.AutoSize = true;
            this.lblsubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsubtotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblsubtotal.Location = new System.Drawing.Point(657, 605);
            this.lblsubtotal.Name = "lblsubtotal";
            this.lblsubtotal.Size = new System.Drawing.Size(22, 7);
            this.lblsubtotal.TabIndex = 141;
            this.lblsubtotal.Text = "00.00";
            // 
            // lblInvoiceNO
            // 
            this.lblInvoiceNO.AutoSize = true;
            this.lblInvoiceNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceNO.Location = new System.Drawing.Point(115, 68);
            this.lblInvoiceNO.Name = "lblInvoiceNO";
            this.lblInvoiceNO.Size = new System.Drawing.Size(12, 16);
            this.lblInvoiceNO.TabIndex = 166;
            this.lblInvoiceNO.Text = "-";
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 800;
            this.toolTip1.AutoPopDelay = 39000;
            this.toolTip1.BackColor = System.Drawing.Color.OliveDrab;
            this.toolTip1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.toolTip1.InitialDelay = 1;
            this.toolTip1.ReshowDelay = 1;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ComboCustID
            // 
            this.ComboCustID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ComboCustID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ComboCustID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.ComboCustID.FormattingEnabled = true;
            this.ComboCustID.Location = new System.Drawing.Point(246, 82);
            this.ComboCustID.Name = "ComboCustID";
            this.ComboCustID.Size = new System.Drawing.Size(316, 33);
            this.ComboCustID.TabIndex = 1;
            this.ComboCustID.Text = "Gest";
            this.toolTip1.SetToolTip(this.ComboCustID, "Select Register Customer. \r\nIf not leave it as a guest\r\n");
            this.ComboCustID.SelectedIndexChanged += new System.EventHandler(this.ComboCustID_SelectedIndexChanged);
            // 
            // txtComment
            // 
            this.txtComment.AcceptsReturn = true;
            this.txtComment.AcceptsTab = true;
            this.txtComment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComment.Location = new System.Drawing.Point(10, 301);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(552, 56);
            this.txtComment.TabIndex = 5;
            this.toolTip1.SetToolTip(this.txtComment, "Comment/ Note");
            // 
            // txtDueAmount
            // 
            this.txtDueAmount.Enabled = false;
            this.txtDueAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDueAmount.Location = new System.Drawing.Point(10, 250);
            this.txtDueAmount.Name = "txtDueAmount";
            this.txtDueAmount.Size = new System.Drawing.Size(209, 26);
            this.txtDueAmount.TabIndex = 159;
            this.toolTip1.SetToolTip(this.txtDueAmount, "Due amount");
            // 
            // txtPaidAmount
            // 
            this.txtPaidAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.65F);
            this.txtPaidAmount.Location = new System.Drawing.Point(10, 82);
            this.txtPaidAmount.Name = "txtPaidAmount";
            this.txtPaidAmount.Size = new System.Drawing.Size(209, 31);
            this.txtPaidAmount.TabIndex = 0;
            this.txtPaidAmount.Text = "00";
            this.toolTip1.SetToolTip(this.txtPaidAmount, "Insert Customer amount");
            this.txtPaidAmount.TextChanged += new System.EventHandler(this.txtPaidAmount_TextChanged);
            // 
            // txtChangeAmount
            // 
            this.txtChangeAmount.Enabled = false;
            this.txtChangeAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChangeAmount.Location = new System.Drawing.Point(10, 199);
            this.txtChangeAmount.Name = "txtChangeAmount";
            this.txtChangeAmount.Size = new System.Drawing.Size(209, 26);
            this.txtChangeAmount.TabIndex = 158;
            this.toolTip1.SetToolTip(this.txtChangeAmount, "Change Amount to back customer");
            // 
            // CombPayby
            // 
            this.CombPayby.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CombPayby.FormattingEnabled = true;
            this.CombPayby.Location = new System.Drawing.Point(247, 200);
            this.CombPayby.Name = "CombPayby";
            this.CombPayby.Size = new System.Drawing.Size(269, 26);
            this.CombPayby.TabIndex = 3;
            this.CombPayby.Text = "Cash";
            this.toolTip1.SetToolTip(this.CombPayby, "Select Payment Type");
            // 
            // txtReffrance
            // 
            this.txtReffrance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReffrance.Location = new System.Drawing.Point(247, 146);
            this.txtReffrance.Name = "txtReffrance";
            this.txtReffrance.Size = new System.Drawing.Size(316, 26);
            this.txtReffrance.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtReffrance, "Change Amount to back customer");
            // 
            // PanelCategoryList
            // 
            this.PanelCategoryList.AutoScroll = true;
            this.PanelCategoryList.Controls.Add(this.flwLyoutCategoryPanel);
            this.PanelCategoryList.Location = new System.Drawing.Point(474, 491);
            this.PanelCategoryList.Name = "PanelCategoryList";
            this.PanelCategoryList.Size = new System.Drawing.Size(443, 107);
            this.PanelCategoryList.TabIndex = 172;
            this.toolTip1.SetToolTip(this.PanelCategoryList, "Categories");
            // 
            // flwLyoutCategoryPanel
            // 
            this.flwLyoutCategoryPanel.AutoSize = true;
            this.flwLyoutCategoryPanel.Location = new System.Drawing.Point(0, 0);
            this.flwLyoutCategoryPanel.Name = "flwLyoutCategoryPanel";
            this.flwLyoutCategoryPanel.Size = new System.Drawing.Size(443, 51);
            this.flwLyoutCategoryPanel.TabIndex = 5;
            this.toolTip1.SetToolTip(this.flwLyoutCategoryPanel, "Categories");
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Transparent;
            this.btnback.FlatAppearance.BorderSize = 0;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F, System.Drawing.FontStyle.Bold);
            this.btnback.ForeColor = System.Drawing.Color.Peru;
            this.btnback.Image = ((System.Drawing.Image)(resources.GetObject("btnback.Image")));
            this.btnback.Location = new System.Drawing.Point(8, 372);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(172, 71);
            this.btnback.TabIndex = 8;
            this.btnback.Text = "Back";
            this.btnback.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnback.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTip1.SetToolTip(this.btnback, "Back to Terminal \r\n");
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnSaveOnly
            // 
            this.btnSaveOnly.BackColor = System.Drawing.Color.Transparent;
            this.btnSaveOnly.FlatAppearance.BorderSize = 0;
            this.btnSaveOnly.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveOnly.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F, System.Drawing.FontStyle.Bold);
            this.btnSaveOnly.ForeColor = System.Drawing.Color.Tan;
            this.btnSaveOnly.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveOnly.Image")));
            this.btnSaveOnly.Location = new System.Drawing.Point(206, 372);
            this.btnSaveOnly.Name = "btnSaveOnly";
            this.btnSaveOnly.Size = new System.Drawing.Size(124, 71);
            this.btnSaveOnly.TabIndex = 6;
            this.btnSaveOnly.Text = "Only Save";
            this.btnSaveOnly.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTip1.SetToolTip(this.btnSaveOnly, "Only Save to database\r\nit will not print receipt");
            this.btnSaveOnly.UseVisualStyleBackColor = false;
            this.btnSaveOnly.Click += new System.EventHandler(this.btnSaveOnly_Click);
            // 
            // btnCompleteSalesAndPrint
            // 
            this.btnCompleteSalesAndPrint.BackColor = System.Drawing.Color.Transparent;
            this.btnCompleteSalesAndPrint.FlatAppearance.BorderSize = 0;
            this.btnCompleteSalesAndPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCompleteSalesAndPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F, System.Drawing.FontStyle.Bold);
            this.btnCompleteSalesAndPrint.ForeColor = System.Drawing.Color.Peru;
            this.btnCompleteSalesAndPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnCompleteSalesAndPrint.Image")));
            this.btnCompleteSalesAndPrint.Location = new System.Drawing.Point(381, 372);
            this.btnCompleteSalesAndPrint.Name = "btnCompleteSalesAndPrint";
            this.btnCompleteSalesAndPrint.Size = new System.Drawing.Size(161, 71);
            this.btnCompleteSalesAndPrint.TabIndex = 7;
            this.btnCompleteSalesAndPrint.Text = "Complete Sale and Print";
            this.btnCompleteSalesAndPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTip1.SetToolTip(this.btnCompleteSalesAndPrint, "Complete Sale and Print\r\n[ENTER]  Press ENTER to Finish");
            this.btnCompleteSalesAndPrint.UseVisualStyleBackColor = true;
            this.btnCompleteSalesAndPrint.Click += new System.EventHandler(this.btnCompleteSalesAndPrint_Click);
            // 
            // btnSaveSplit
            // 
            this.btnSaveSplit.BackColor = System.Drawing.Color.Transparent;
            this.btnSaveSplit.FlatAppearance.BorderSize = 0;
            this.btnSaveSplit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveSplit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F, System.Drawing.FontStyle.Bold);
            this.btnSaveSplit.ForeColor = System.Drawing.Color.Tan;
            this.btnSaveSplit.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveSplit.Image")));
            this.btnSaveSplit.Location = new System.Drawing.Point(759, 31);
            this.btnSaveSplit.Name = "btnSaveSplit";
            this.btnSaveSplit.Size = new System.Drawing.Size(124, 71);
            this.btnSaveSplit.TabIndex = 194;
            this.btnSaveSplit.Text = "Only Save";
            this.btnSaveSplit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTip1.SetToolTip(this.btnSaveSplit, "Only Save to database\r\nit will not print receipt");
            this.btnSaveSplit.UseVisualStyleBackColor = false;
            this.btnSaveSplit.Click += new System.EventHandler(this.btnSaveSplit_Click);
            // 
            // btnSplitPrint
            // 
            this.btnSplitPrint.BackColor = System.Drawing.Color.Transparent;
            this.btnSplitPrint.FlatAppearance.BorderSize = 0;
            this.btnSplitPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSplitPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F, System.Drawing.FontStyle.Bold);
            this.btnSplitPrint.ForeColor = System.Drawing.Color.Peru;
            this.btnSplitPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnSplitPrint.Image")));
            this.btnSplitPrint.Location = new System.Drawing.Point(934, 31);
            this.btnSplitPrint.Name = "btnSplitPrint";
            this.btnSplitPrint.Size = new System.Drawing.Size(161, 71);
            this.btnSplitPrint.TabIndex = 193;
            this.btnSplitPrint.Text = "Complete Sale and Print";
            this.btnSplitPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTip1.SetToolTip(this.btnSplitPrint, "Complete Sale and Print\r\n[ENTER]  Press ENTER to Finish");
            this.btnSplitPrint.UseVisualStyleBackColor = true;
            this.btnSplitPrint.Click += new System.EventHandler(this.btnSplitPrint_Click);
            // 
            // txtSearchItem
            // 
            this.txtSearchItem.BackColor = System.Drawing.SystemColors.Control;
            this.txtSearchItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchItem.Location = new System.Drawing.Point(7, 26);
            this.txtSearchItem.Name = "txtSearchItem";
            this.txtSearchItem.Size = new System.Drawing.Size(233, 24);
            this.txtSearchItem.TabIndex = 176;
            this.toolTip1.SetToolTip(this.txtSearchItem, "Search by Product Code / Barcode OR  Name ");
            this.txtSearchItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearchItem_KeyDown_1);
            this.txtSearchItem.Leave += new System.EventHandler(this.txtSearchItem_Leave);
            // 
            // txtBarcodeReaderBox
            // 
            this.txtBarcodeReaderBox.BackColor = System.Drawing.SystemColors.Control;
            this.txtBarcodeReaderBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBarcodeReaderBox.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarcodeReaderBox.Location = new System.Drawing.Point(307, 29);
            this.txtBarcodeReaderBox.Name = "txtBarcodeReaderBox";
            this.txtBarcodeReaderBox.Size = new System.Drawing.Size(132, 22);
            this.txtBarcodeReaderBox.TabIndex = 169;
            this.toolTip1.SetToolTip(this.txtBarcodeReaderBox, "Insert item Bar-code with Barcode scanner");
            this.txtBarcodeReaderBox.TextChanged += new System.EventHandler(this.txtBarcodeReaderBox_TextChanged);
            this.txtBarcodeReaderBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBarcodeReaderBox_KeyDown);
            // 
            // currency_Shortcuts1
            // 
            this.currency_Shortcuts1.BackColor = System.Drawing.Color.Transparent;
            this.currency_Shortcuts1.Location = new System.Drawing.Point(611, 34);
            this.currency_Shortcuts1.Name = "currency_Shortcuts1";
            this.currency_Shortcuts1.Size = new System.Drawing.Size(320, 307);
            this.currency_Shortcuts1.TabIndex = 175;
            this.toolTip1.SetToolTip(this.currency_Shortcuts1, "Coin and paper money shortcuts");
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // helplnk
            // 
            this.helplnk.AutoSize = true;
            this.helplnk.Location = new System.Drawing.Point(892, 605);
            this.helplnk.Name = "helplnk";
            this.helplnk.Size = new System.Drawing.Size(29, 13);
            this.helplnk.TabIndex = 156;
            this.helplnk.TabStop = true;
            this.helplnk.Text = "Help";
            this.helplnk.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.helplnk_LinkClicked);
            // 
            // linkLabelCalculator
            // 
            this.linkLabelCalculator.AutoSize = true;
            this.linkLabelCalculator.Location = new System.Drawing.Point(548, 601);
            this.linkLabelCalculator.Name = "linkLabelCalculator";
            this.linkLabelCalculator.Size = new System.Drawing.Size(54, 13);
            this.linkLabelCalculator.TabIndex = 162;
            this.linkLabelCalculator.TabStop = true;
            this.linkLabelCalculator.Text = "Calculator";
            this.linkLabelCalculator.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // tabSRcontrol
            // 
            this.tabSRcontrol.Controls.Add(this.tabPageSR_Counter);
            this.tabSRcontrol.Controls.Add(this.tabPageSR_Payment);
            this.tabSRcontrol.Controls.Add(this.tabPageSR_Split_Bill);
            this.tabSRcontrol.Controls.Add(this.tabCashier);
            this.tabSRcontrol.Controls.Add(this.tabDelivery);
            this.tabSRcontrol.ImageList = this.imageList1;
            this.tabSRcontrol.ItemSize = new System.Drawing.Size(102, 30);
            this.tabSRcontrol.Location = new System.Drawing.Point(0, 2);
            this.tabSRcontrol.Name = "tabSRcontrol";
            this.tabSRcontrol.SelectedIndex = 0;
            this.tabSRcontrol.Size = new System.Drawing.Size(935, 664);
            this.tabSRcontrol.TabIndex = 165;
            this.tabSRcontrol.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabSRcontrol_Selecting);
            // 
            // tabPageSR_Counter
            // 
            this.tabPageSR_Counter.Controls.Add(this.lblmainCustwalletant);
            this.tabPageSR_Counter.Controls.Add(this.lblDeliverydate);
            this.tabPageSR_Counter.Controls.Add(this.dtsaleDeliveryDate);
            this.tabPageSR_Counter.Controls.Add(this.lblIsReciepe);
            this.tabPageSR_Counter.Controls.Add(this.lblSerialize);
            this.tabPageSR_Counter.Controls.Add(this.panel8);
            this.tabPageSR_Counter.Controls.Add(this.label20);
            this.tabPageSR_Counter.Controls.Add(this.radiocredit);
            this.tabPageSR_Counter.Controls.Add(this.radioCash);
            this.tabPageSR_Counter.Controls.Add(this.dtsaleDate);
            this.tabPageSR_Counter.Controls.Add(this.label18);
            this.tabPageSR_Counter.Controls.Add(this.lblsubtotal);
            this.tabPageSR_Counter.Controls.Add(this.lblstart);
            this.tabPageSR_Counter.Controls.Add(this.lblPerishable);
            this.tabPageSR_Counter.Controls.Add(this.lblorderNO);
            this.tabPageSR_Counter.Controls.Add(this.linkLabelRefresh);
            this.tabPageSR_Counter.Controls.Add(this.labelCustomerName);
            this.tabPageSR_Counter.Controls.Add(this.linkLabel3);
            this.tabPageSR_Counter.Controls.Add(this.PanelCategoryList);
            this.tabPageSR_Counter.Controls.Add(this.txtInvoice);
            this.tabPageSR_Counter.Controls.Add(this.txtCustomer);
            this.tabPageSR_Counter.Controls.Add(this.tabControl1);
            this.tabPageSR_Counter.Controls.Add(this.comboSalesMan);
            this.tabPageSR_Counter.Controls.Add(this.linkLabelCalculator);
            this.tabPageSR_Counter.Controls.Add(this.ItemcartPanel);
            this.tabPageSR_Counter.Controls.Add(this.panel3);
            this.tabPageSR_Counter.Controls.Add(this.lblInvoiceNO);
            this.tabPageSR_Counter.Controls.Add(this.helplnk);
            this.tabPageSR_Counter.ImageIndex = 42;
            this.tabPageSR_Counter.Location = new System.Drawing.Point(4, 34);
            this.tabPageSR_Counter.Name = "tabPageSR_Counter";
            this.tabPageSR_Counter.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSR_Counter.Size = new System.Drawing.Size(927, 626);
            this.tabPageSR_Counter.TabIndex = 0;
            this.tabPageSR_Counter.Text = "Terminal        ";
            this.tabPageSR_Counter.UseVisualStyleBackColor = true;
            this.tabPageSR_Counter.Enter += new System.EventHandler(this.tabPageSR_Counter_Enter);
            // 
            // lblmainCustwalletant
            // 
            this.lblmainCustwalletant.AutoSize = true;
            this.lblmainCustwalletant.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmainCustwalletant.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblmainCustwalletant.Location = new System.Drawing.Point(317, 11);
            this.lblmainCustwalletant.Name = "lblmainCustwalletant";
            this.lblmainCustwalletant.Size = new System.Drawing.Size(14, 15);
            this.lblmainCustwalletant.TabIndex = 184;
            this.lblmainCustwalletant.Text = "0";
            this.lblmainCustwalletant.Visible = false;
            // 
            // lblDeliverydate
            // 
            this.lblDeliverydate.AutoSize = true;
            this.lblDeliverydate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDeliverydate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeliverydate.Location = new System.Drawing.Point(264, 39);
            this.lblDeliverydate.Name = "lblDeliverydate";
            this.lblDeliverydate.Size = new System.Drawing.Size(93, 20);
            this.lblDeliverydate.TabIndex = 186;
            this.lblDeliverydate.Text = "Delivery         ";
            // 
            // dtsaleDeliveryDate
            // 
            this.dtsaleDeliveryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dtsaleDeliveryDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtsaleDeliveryDate.Location = new System.Drawing.Point(367, 36);
            this.dtsaleDeliveryDate.Name = "dtsaleDeliveryDate";
            this.dtsaleDeliveryDate.Size = new System.Drawing.Size(100, 23);
            this.dtsaleDeliveryDate.TabIndex = 185;
            // 
            // lblIsReciepe
            // 
            this.lblIsReciepe.AutoSize = true;
            this.lblIsReciepe.Location = new System.Drawing.Point(620, 605);
            this.lblIsReciepe.Name = "lblIsReciepe";
            this.lblIsReciepe.Size = new System.Drawing.Size(10, 13);
            this.lblIsReciepe.TabIndex = 184;
            this.lblIsReciepe.Text = "-";
            // 
            // lblSerialize
            // 
            this.lblSerialize.AutoSize = true;
            this.lblSerialize.Location = new System.Drawing.Point(861, 605);
            this.lblSerialize.Name = "lblSerialize";
            this.lblSerialize.Size = new System.Drawing.Size(10, 13);
            this.lblSerialize.TabIndex = 183;
            this.lblSerialize.Text = "-";
            this.lblSerialize.TextChanged += new System.EventHandler(this.lblSerialize_TextChanged);
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.chkbutton);
            this.panel8.Controls.Add(this.chkWithGrid);
            this.panel8.Controls.Add(this.btnSerchItem);
            this.panel8.Controls.Add(this.txtSearchItem);
            this.panel8.Controls.Add(this.txtBarcodeReaderBox);
            this.panel8.Controls.Add(this.chkoutput);
            this.panel8.Controls.Add(this.chkImage);
            this.panel8.Controls.Add(this.itemCount);
            this.panel8.Controls.Add(this.lblCatagory);
            this.panel8.Controls.Add(this.labelSearchItems);
            this.panel8.Controls.Add(this.lblInsertitembarcode);
            this.panel8.Location = new System.Drawing.Point(474, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(447, 58);
            this.panel8.TabIndex = 182;
            // 
            // chkbutton
            // 
            this.chkbutton.AutoSize = true;
            this.chkbutton.Checked = true;
            this.chkbutton.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbutton.Location = new System.Drawing.Point(197, 5);
            this.chkbutton.Name = "chkbutton";
            this.chkbutton.Size = new System.Drawing.Size(51, 16);
            this.chkbutton.TabIndex = 179;
            this.chkbutton.Text = "Button";
            this.chkbutton.UseVisualStyleBackColor = true;
            this.chkbutton.CheckedChanged += new System.EventHandler(this.chkbutton_CheckedChanged);
            // 
            // chkWithGrid
            // 
            this.chkWithGrid.AutoSize = true;
            this.chkWithGrid.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWithGrid.Location = new System.Drawing.Point(258, 5);
            this.chkWithGrid.Name = "chkWithGrid";
            this.chkWithGrid.Size = new System.Drawing.Size(41, 16);
            this.chkWithGrid.TabIndex = 178;
            this.chkWithGrid.Text = "Grid";
            this.chkWithGrid.UseVisualStyleBackColor = true;
            this.chkWithGrid.CheckedChanged += new System.EventHandler(this.chkWithGrid_CheckedChanged);
            // 
            // btnSerchItem
            // 
            this.btnSerchItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSerchItem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSerchItem.FlatAppearance.BorderSize = 0;
            this.btnSerchItem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSerchItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSerchItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnSerchItem.Image = ((System.Drawing.Image)(resources.GetObject("btnSerchItem.Image")));
            this.btnSerchItem.Location = new System.Drawing.Point(243, 26);
            this.btnSerchItem.Name = "btnSerchItem";
            this.btnSerchItem.Size = new System.Drawing.Size(24, 25);
            this.btnSerchItem.TabIndex = 177;
            this.btnSerchItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSerchItem.UseVisualStyleBackColor = false;
            this.btnSerchItem.Click += new System.EventHandler(this.btnSerchItem_Click);
            // 
            // chkoutput
            // 
            this.chkoutput.AutoSize = true;
            this.chkoutput.Checked = true;
            this.chkoutput.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkoutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkoutput.Location = new System.Drawing.Point(366, 5);
            this.chkoutput.Name = "chkoutput";
            this.chkoutput.Size = new System.Drawing.Size(73, 16);
            this.chkoutput.TabIndex = 175;
            this.chkoutput.Text = "Output Item";
            this.chkoutput.UseVisualStyleBackColor = true;
            this.chkoutput.CheckedChanged += new System.EventHandler(this.chkoutput_CheckedChanged);
            // 
            // chkImage
            // 
            this.chkImage.AutoSize = true;
            this.chkImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkImage.Location = new System.Drawing.Point(307, 5);
            this.chkImage.Name = "chkImage";
            this.chkImage.Size = new System.Drawing.Size(50, 16);
            this.chkImage.TabIndex = 174;
            this.chkImage.Text = "Image";
            this.chkImage.UseVisualStyleBackColor = true;
            this.chkImage.CheckedChanged += new System.EventHandler(this.chkImage_CheckedChanged);
            // 
            // itemCount
            // 
            this.itemCount.AutoSize = true;
            this.itemCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemCount.ForeColor = System.Drawing.Color.Black;
            this.itemCount.Location = new System.Drawing.Point(107, 6);
            this.itemCount.Name = "itemCount";
            this.itemCount.Size = new System.Drawing.Size(11, 15);
            this.itemCount.TabIndex = 173;
            this.itemCount.Text = "-";
            this.itemCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblCatagory
            // 
            this.lblCatagory.AutoSize = true;
            this.lblCatagory.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCatagory.ForeColor = System.Drawing.Color.Red;
            this.lblCatagory.Location = new System.Drawing.Point(143, 9);
            this.lblCatagory.Name = "lblCatagory";
            this.lblCatagory.Size = new System.Drawing.Size(8, 9);
            this.lblCatagory.TabIndex = 172;
            this.lblCatagory.Text = "-";
            this.lblCatagory.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSearchItems
            // 
            this.labelSearchItems.AutoSize = true;
            this.labelSearchItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearchItems.Location = new System.Drawing.Point(7, 7);
            this.labelSearchItems.Name = "labelSearchItems";
            this.labelSearchItems.Size = new System.Drawing.Size(60, 12);
            this.labelSearchItems.TabIndex = 171;
            this.labelSearchItems.Text = "Search Items";
            // 
            // lblInsertitembarcode
            // 
            this.lblInsertitembarcode.AutoSize = true;
            this.lblInsertitembarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInsertitembarcode.Location = new System.Drawing.Point(270, 32);
            this.lblInsertitembarcode.Name = "lblInsertitembarcode";
            this.lblInsertitembarcode.Size = new System.Drawing.Size(41, 12);
            this.lblInsertitembarcode.TabIndex = 170;
            this.lblInsertitembarcode.Text = "barcode:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(101, 20);
            this.label20.TabIndex = 181;
            this.label20.Text = "Date                ";
            // 
            // radiocredit
            // 
            this.radiocredit.AutoSize = true;
            this.radiocredit.Location = new System.Drawing.Point(418, 10);
            this.radiocredit.Name = "radiocredit";
            this.radiocredit.Size = new System.Drawing.Size(52, 17);
            this.radiocredit.TabIndex = 180;
            this.radiocredit.Text = "Credit";
            this.radiocredit.UseVisualStyleBackColor = true;
            this.radiocredit.CheckedChanged += new System.EventHandler(this.radiocredit_CheckedChanged);
            // 
            // radioCash
            // 
            this.radioCash.AutoSize = true;
            this.radioCash.Checked = true;
            this.radioCash.Location = new System.Drawing.Point(370, 9);
            this.radioCash.Name = "radioCash";
            this.radioCash.Size = new System.Drawing.Size(49, 17);
            this.radioCash.TabIndex = 179;
            this.radioCash.TabStop = true;
            this.radioCash.Text = "Cash";
            this.radioCash.UseVisualStyleBackColor = true;
            this.radioCash.CheckedChanged += new System.EventHandler(this.radioCash_CheckedChanged);
            // 
            // dtsaleDate
            // 
            this.dtsaleDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dtsaleDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtsaleDate.Location = new System.Drawing.Point(115, 38);
            this.dtsaleDate.Name = "dtsaleDate";
            this.dtsaleDate.Size = new System.Drawing.Size(143, 23);
            this.dtsaleDate.TabIndex = 177;
            this.dtsaleDate.ValueChanged += new System.EventHandler(this.dtsaleDate_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 65);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 20);
            this.label18.TabIndex = 176;
            this.label18.Text = "Invoice No:      ";
            // 
            // lblstart
            // 
            this.lblstart.AutoSize = true;
            this.lblstart.Location = new System.Drawing.Point(797, 601);
            this.lblstart.Name = "lblstart";
            this.lblstart.Size = new System.Drawing.Size(10, 13);
            this.lblstart.TabIndex = 155;
            this.lblstart.Text = "-";
            // 
            // lblPerishable
            // 
            this.lblPerishable.AutoSize = true;
            this.lblPerishable.Location = new System.Drawing.Point(742, 601);
            this.lblPerishable.Name = "lblPerishable";
            this.lblPerishable.Size = new System.Drawing.Size(10, 13);
            this.lblPerishable.TabIndex = 175;
            this.lblPerishable.Text = "-";
            this.lblPerishable.TextChanged += new System.EventHandler(this.lblPerishable_TextChanged);
            // 
            // lblorderNO
            // 
            this.lblorderNO.AutoSize = true;
            this.lblorderNO.Location = new System.Drawing.Point(692, 598);
            this.lblorderNO.Name = "lblorderNO";
            this.lblorderNO.Size = new System.Drawing.Size(10, 13);
            this.lblorderNO.TabIndex = 174;
            this.lblorderNO.Text = "-";
            this.lblorderNO.TextChanged += new System.EventHandler(this.lblorderNO_TextChanged);
            // 
            // linkLabelRefresh
            // 
            this.linkLabelRefresh.AutoSize = true;
            this.linkLabelRefresh.Location = new System.Drawing.Point(471, 601);
            this.linkLabelRefresh.Name = "linkLabelRefresh";
            this.linkLabelRefresh.Size = new System.Drawing.Size(44, 13);
            this.linkLabelRefresh.TabIndex = 173;
            this.linkLabelRefresh.TabStop = true;
            this.linkLabelRefresh.Text = "Refresh";
            this.linkLabelRefresh.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // labelCustomerName
            // 
            this.labelCustomerName.AutoSize = true;
            this.labelCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelCustomerName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCustomerName.Location = new System.Drawing.Point(6, 8);
            this.labelCustomerName.Name = "labelCustomerName";
            this.labelCustomerName.Size = new System.Drawing.Size(103, 20);
            this.labelCustomerName.TabIndex = 162;
            this.labelCustomerName.Text = "Customer Name";
            this.labelCustomerName.Click += new System.EventHandler(this.label9_Click);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel3.Location = new System.Drawing.Point(291, 3);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(33, 33);
            this.linkLabel3.TabIndex = 170;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "+";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // txtCustomer
            // 
            this.txtCustomer.BackColor = System.Drawing.Color.LightSkyBlue;
            this.txtCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomer.Location = new System.Drawing.Point(115, 6);
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.Size = new System.Drawing.Size(180, 26);
            this.txtCustomer.TabIndex = 165;
            this.txtCustomer.Text = "Cash";
            this.txtCustomer.TextChanged += new System.EventHandler(this.txtCustomer_TextChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ItemButton);
            this.tabControl1.Controls.Add(this.ItemGrid);
            this.tabControl1.Controls.Add(this.ItemsImage);
            this.tabControl1.Controls.Add(this.RelatedItems);
            this.tabControl1.Controls.Add(this.Catagories);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ImageList = this.imageList1;
            this.tabControl1.ItemSize = new System.Drawing.Size(46, 30);
            this.tabControl1.Location = new System.Drawing.Point(474, 61);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(447, 425);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 169;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // ItemButton
            // 
            this.ItemButton.Controls.Add(this.panel9);
            this.ItemButton.Location = new System.Drawing.Point(4, 34);
            this.ItemButton.Name = "ItemButton";
            this.ItemButton.Size = new System.Drawing.Size(439, 387);
            this.ItemButton.TabIndex = 4;
            this.ItemButton.Text = "Item Button";
            this.ItemButton.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.flowLayoutPanelItemListButton);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(439, 387);
            this.panel9.TabIndex = 0;
            // 
            // flowLayoutPanelItemListButton
            // 
            this.flowLayoutPanelItemListButton.AutoScroll = true;
            this.flowLayoutPanelItemListButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelItemListButton.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelItemListButton.Name = "flowLayoutPanelItemListButton";
            this.flowLayoutPanelItemListButton.Size = new System.Drawing.Size(439, 387);
            this.flowLayoutPanelItemListButton.TabIndex = 0;
            // 
            // ItemGrid
            // 
            this.ItemGrid.Controls.Add(this.PanelStockList1);
            this.ItemGrid.Location = new System.Drawing.Point(4, 34);
            this.ItemGrid.Name = "ItemGrid";
            this.ItemGrid.Size = new System.Drawing.Size(439, 387);
            this.ItemGrid.TabIndex = 3;
            this.ItemGrid.Text = "Item Grid  ";
            this.ItemGrid.UseVisualStyleBackColor = true;
            // 
            // PanelStockList1
            // 
            this.PanelStockList1.Controls.Add(this.dgrvProductList);
            this.PanelStockList1.Location = new System.Drawing.Point(3, 3);
            this.PanelStockList1.Name = "PanelStockList1";
            this.PanelStockList1.Size = new System.Drawing.Size(433, 381);
            this.PanelStockList1.TabIndex = 170;
            // 
            // dgrvProductList
            // 
            this.dgrvProductList.AllowUserToAddRows = false;
            this.dgrvProductList.AllowUserToDeleteRows = false;
            this.dgrvProductList.AllowUserToResizeColumns = false;
            this.dgrvProductList.AllowUserToResizeRows = false;
            this.dgrvProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgrvProductList.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgrvProductList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrvProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgrvProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrvProductList.DefaultCellStyle = dataGridViewCellStyle16;
            this.dgrvProductList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgrvProductList.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dgrvProductList.Location = new System.Drawing.Point(0, 0);
            this.dgrvProductList.Name = "dgrvProductList";
            this.dgrvProductList.RowHeadersVisible = false;
            this.dgrvProductList.RowTemplate.Height = 44;
            this.dgrvProductList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrvProductList.Size = new System.Drawing.Size(433, 381);
            this.dgrvProductList.TabIndex = 183;
            this.dgrvProductList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvProductList_CellContentClick);
            this.dgrvProductList.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgrvProductList_DataBindingComplete);
            // 
            // ItemsImage
            // 
            this.ItemsImage.Controls.Add(this.PanelStockList);
            this.ItemsImage.Location = new System.Drawing.Point(4, 34);
            this.ItemsImage.Name = "ItemsImage";
            this.ItemsImage.Padding = new System.Windows.Forms.Padding(3);
            this.ItemsImage.Size = new System.Drawing.Size(439, 387);
            this.ItemsImage.TabIndex = 0;
            this.ItemsImage.Text = "Items  Image";
            this.ItemsImage.UseVisualStyleBackColor = true;
            // 
            // PanelStockList
            // 
            this.PanelStockList.Controls.Add(this.flowLayoutPanelItemList);
            this.PanelStockList.Location = new System.Drawing.Point(2, 6);
            this.PanelStockList.Name = "PanelStockList";
            this.PanelStockList.Size = new System.Drawing.Size(434, 378);
            this.PanelStockList.TabIndex = 159;
            // 
            // flowLayoutPanelItemList
            // 
            this.flowLayoutPanelItemList.AutoScroll = true;
            this.flowLayoutPanelItemList.AutoSize = true;
            this.flowLayoutPanelItemList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelItemList.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelItemList.Name = "flowLayoutPanelItemList";
            this.flowLayoutPanelItemList.Size = new System.Drawing.Size(434, 378);
            this.flowLayoutPanelItemList.TabIndex = 5;
            // 
            // RelatedItems
            // 
            this.RelatedItems.Controls.Add(this.panel1);
            this.RelatedItems.Location = new System.Drawing.Point(4, 34);
            this.RelatedItems.Name = "RelatedItems";
            this.RelatedItems.Padding = new System.Windows.Forms.Padding(3);
            this.RelatedItems.Size = new System.Drawing.Size(439, 387);
            this.RelatedItems.TabIndex = 1;
            this.RelatedItems.Text = " Related Items      ";
            this.RelatedItems.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.PenalRelateditems);
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(432, 380);
            this.panel1.TabIndex = 162;
            // 
            // PenalRelateditems
            // 
            this.PenalRelateditems.AutoScroll = true;
            this.PenalRelateditems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PenalRelateditems.Location = new System.Drawing.Point(0, 0);
            this.PenalRelateditems.Name = "PenalRelateditems";
            this.PenalRelateditems.Size = new System.Drawing.Size(432, 380);
            this.PenalRelateditems.TabIndex = 5;
            // 
            // Catagories
            // 
            this.Catagories.Controls.Add(this.panel2);
            this.Catagories.Location = new System.Drawing.Point(4, 34);
            this.Catagories.Name = "Catagories";
            this.Catagories.Size = new System.Drawing.Size(439, 387);
            this.Catagories.TabIndex = 2;
            this.Catagories.Text = "Catagories     ";
            this.Catagories.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.PanelCatagories);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(432, 380);
            this.panel2.TabIndex = 163;
            // 
            // PanelCatagories
            // 
            this.PanelCatagories.AutoScroll = true;
            this.PanelCatagories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelCatagories.Location = new System.Drawing.Point(0, 0);
            this.PanelCatagories.Name = "PanelCatagories";
            this.PanelCatagories.Size = new System.Drawing.Size(432, 380);
            this.PanelCatagories.TabIndex = 5;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Architect.png");
            this.imageList1.Images.SetKeyName(1, "Cashier1.jpg");
            this.imageList1.Images.SetKeyName(2, "Cashier2.png");
            this.imageList1.Images.SetKeyName(3, "Cashier3.png");
            this.imageList1.Images.SetKeyName(4, "Cashier4.png");
            this.imageList1.Images.SetKeyName(5, "CashOnDelivery1.jpg");
            this.imageList1.Images.SetKeyName(6, "CashOnDelivery2.jpg");
            this.imageList1.Images.SetKeyName(7, "Category.jpg");
            this.imageList1.Images.SetKeyName(8, "Category2.jpg");
            this.imageList1.Images.SetKeyName(9, "Category3.png");
            this.imageList1.Images.SetKeyName(10, "Category4.jpg");
            this.imageList1.Images.SetKeyName(11, "CheckBox.png");
            this.imageList1.Images.SetKeyName(12, "Degree.png");
            this.imageList1.Images.SetKeyName(13, "Delivered.jpg");
            this.imageList1.Images.SetKeyName(14, "Driver1.png");
            this.imageList1.Images.SetKeyName(15, "Driver2.jpg");
            this.imageList1.Images.SetKeyName(16, "Driver3.png");
            this.imageList1.Images.SetKeyName(17, "EyeSearch.png");
            this.imageList1.Images.SetKeyName(18, "home-300x300.png");
            this.imageList1.Images.SetKeyName(19, "HomeOwner.png");
            this.imageList1.Images.SetKeyName(20, "Items1.png");
            this.imageList1.Images.SetKeyName(21, "Items2.png");
            this.imageList1.Images.SetKeyName(22, "Packaging1.jpg");
            this.imageList1.Images.SetKeyName(23, "Payment1.png");
            this.imageList1.Images.SetKeyName(24, "Payment2.jpg");
            this.imageList1.Images.SetKeyName(25, "Payment3.png");
            this.imageList1.Images.SetKeyName(26, "Payment4.png");
            this.imageList1.Images.SetKeyName(27, "Payment5.png");
            this.imageList1.Images.SetKeyName(28, "prestashop-facebook-comments.jpg");
            this.imageList1.Images.SetKeyName(29, "prestashop-virtual-combinations.jpg");
            this.imageList1.Images.SetKeyName(30, "product-extra-left-links.jpg");
            this.imageList1.Images.SetKeyName(31, "RelatedItems1.jpg");
            this.imageList1.Images.SetKeyName(32, "RelatedItems2.jpg");
            this.imageList1.Images.SetKeyName(33, "RelatedItems3.jpg");
            this.imageList1.Images.SetKeyName(34, "RelatedItems4.jpg");
            this.imageList1.Images.SetKeyName(35, "RelatedItems5.png");
            this.imageList1.Images.SetKeyName(36, "Return1.png");
            this.imageList1.Images.SetKeyName(37, "return-icon-160-25121016.jpg");
            this.imageList1.Images.SetKeyName(38, "Tools.png");
            this.imageList1.Images.SetKeyName(39, "Verified.png");
            this.imageList1.Images.SetKeyName(40, "Walking.png");
            this.imageList1.Images.SetKeyName(41, "Writting.jpg");
            this.imageList1.Images.SetKeyName(42, "Terminal.png");
            this.imageList1.Images.SetKeyName(43, "Split Bill.jpg");
            // 
            // comboSalesMan
            // 
            this.comboSalesMan.FormattingEnabled = true;
            this.comboSalesMan.Items.AddRange(new object[] {
            "Walk In",
            "Salesman name",
            "Foodiz"});
            this.comboSalesMan.Location = new System.Drawing.Point(308, 61);
            this.comboSalesMan.Name = "comboSalesMan";
            this.comboSalesMan.Size = new System.Drawing.Size(165, 21);
            this.comboSalesMan.TabIndex = 168;
            this.comboSalesMan.SelectedIndexChanged += new System.EventHandler(this.comboSalesMan_SelectedIndexChanged);
            // 
            // tabPageSR_Payment
            // 
            this.tabPageSR_Payment.Controls.Add(this.lblCustAvailableAmt);
            this.tabPageSR_Payment.Controls.Add(this.label19);
            this.tabPageSR_Payment.Controls.Add(this.btnAppGridAdd);
            this.tabPageSR_Payment.Controls.Add(this.lnkCustomer);
            this.tabPageSR_Payment.Controls.Add(this.linkLabel4);
            this.tabPageSR_Payment.Controls.Add(this.chkCreditTrans);
            this.tabPageSR_Payment.Controls.Add(this.label16);
            this.tabPageSR_Payment.Controls.Add(this.txtInvoicePAY);
            this.tabPageSR_Payment.Controls.Add(this.lblInvoiceNOPAY);
            this.tabPageSR_Payment.Controls.Add(this.linkLabel2);
            this.tabPageSR_Payment.Controls.Add(this.txtReffrance);
            this.tabPageSR_Payment.Controls.Add(this.labelReffranceNo);
            this.tabPageSR_Payment.Controls.Add(this.lblPaid);
            this.tabPageSR_Payment.Controls.Add(this.GridPayment);
            this.tabPageSR_Payment.Controls.Add(this.linkLabelAddNew);
            this.tabPageSR_Payment.Controls.Add(this.lblTotalpayableAmtPY);
            this.tabPageSR_Payment.Controls.Add(this.label1TotalPayable);
            this.tabPageSR_Payment.Controls.Add(this.labelShortcuts);
            this.tabPageSR_Payment.Controls.Add(this.lblCustID);
            this.tabPageSR_Payment.Controls.Add(this.ComboCustID);
            this.tabPageSR_Payment.Controls.Add(this.labelInsertCustomeramount);
            this.tabPageSR_Payment.Controls.Add(this.label1Optional);
            this.tabPageSR_Payment.Controls.Add(this.labelComment);
            this.tabPageSR_Payment.Controls.Add(this.txtComment);
            this.tabPageSR_Payment.Controls.Add(this.txtDueAmount);
            this.tabPageSR_Payment.Controls.Add(this.labelDue);
            this.tabPageSR_Payment.Controls.Add(this.txtPaidAmount);
            this.tabPageSR_Payment.Controls.Add(this.txtChangeAmount);
            this.tabPageSR_Payment.Controls.Add(this.label1ChangeAmount);
            this.tabPageSR_Payment.Controls.Add(this.labelPaidAmount);
            this.tabPageSR_Payment.Controls.Add(this.labelPayby);
            this.tabPageSR_Payment.Controls.Add(this.CombPayby);
            this.tabPageSR_Payment.Controls.Add(this.labelSalesDate);
            this.tabPageSR_Payment.Controls.Add(this.dtSalesDate);
            this.tabPageSR_Payment.Controls.Add(this.RefrashPayby);
            this.tabPageSR_Payment.Controls.Add(this.btnrefrash);
            this.tabPageSR_Payment.Controls.Add(this.btnback);
            this.tabPageSR_Payment.Controls.Add(this.btnSaveOnly);
            this.tabPageSR_Payment.Controls.Add(this.btnCompleteSalesAndPrint);
            this.tabPageSR_Payment.Controls.Add(this.currency_Shortcuts1);
            this.tabPageSR_Payment.ImageIndex = 23;
            this.tabPageSR_Payment.Location = new System.Drawing.Point(4, 34);
            this.tabPageSR_Payment.Name = "tabPageSR_Payment";
            this.tabPageSR_Payment.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSR_Payment.Size = new System.Drawing.Size(927, 626);
            this.tabPageSR_Payment.TabIndex = 1;
            this.tabPageSR_Payment.Text = "Payment        ";
            this.tabPageSR_Payment.UseVisualStyleBackColor = true;
            this.tabPageSR_Payment.Enter += new System.EventHandler(this.tabPageSR_Payment_Enter);
            // 
            // lblCustAvailableAmt
            // 
            this.lblCustAvailableAmt.AutoSize = true;
            this.lblCustAvailableAmt.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustAvailableAmt.ForeColor = System.Drawing.Color.Black;
            this.lblCustAvailableAmt.Location = new System.Drawing.Point(154, 15);
            this.lblCustAvailableAmt.Name = "lblCustAvailableAmt";
            this.lblCustAvailableAmt.Size = new System.Drawing.Size(30, 23);
            this.lblCustAvailableAmt.TabIndex = 227;
            this.lblCustAvailableAmt.Text = "00";
            this.lblCustAvailableAmt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.LimeGreen;
            this.label19.Location = new System.Drawing.Point(9, 14);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(149, 23);
            this.label19.TabIndex = 226;
            this.label19.Text = "Advance Amount :";
            // 
            // btnAppGridAdd
            // 
            this.btnAppGridAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnAppGridAdd.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAppGridAdd.FlatAppearance.BorderSize = 0;
            this.btnAppGridAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAppGridAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAppGridAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnAppGridAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAppGridAdd.Image")));
            this.btnAppGridAdd.Location = new System.Drawing.Point(529, 197);
            this.btnAppGridAdd.Name = "btnAppGridAdd";
            this.btnAppGridAdd.Size = new System.Drawing.Size(29, 31);
            this.btnAppGridAdd.TabIndex = 225;
            this.btnAppGridAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAppGridAdd.UseVisualStyleBackColor = false;
            this.btnAppGridAdd.Click += new System.EventHandler(this.btnAppGridAdd_Click);
            // 
            // lnkCustomer
            // 
            this.lnkCustomer.AutoSize = true;
            this.lnkCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkCustomer.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkCustomer.Location = new System.Drawing.Point(244, 60);
            this.lnkCustomer.Name = "lnkCustomer";
            this.lnkCustomer.Size = new System.Drawing.Size(86, 18);
            this.lnkCustomer.TabIndex = 206;
            this.lnkCustomer.TabStop = true;
            this.lnkCustomer.Text = "Customer  :";
            this.lnkCustomer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCustomer_LinkClicked);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Location = new System.Drawing.Point(465, 181);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(51, 13);
            this.linkLabel4.TabIndex = 205;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "Add New";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked_1);
            // 
            // chkCreditTrans
            // 
            this.chkCreditTrans.AutoSize = true;
            this.chkCreditTrans.BackColor = System.Drawing.Color.LightSalmon;
            this.chkCreditTrans.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCreditTrans.Location = new System.Drawing.Point(13, 140);
            this.chkCreditTrans.Name = "chkCreditTrans";
            this.chkCreditTrans.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.chkCreditTrans.Size = new System.Drawing.Size(171, 24);
            this.chkCreditTrans.TabIndex = 9;
            this.chkCreditTrans.Text = "Creadit Transaction";
            this.chkCreditTrans.UseVisualStyleBackColor = false;
            this.chkCreditTrans.CheckedChanged += new System.EventHandler(this.chkCreditTrans_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label16.Location = new System.Drawing.Point(928, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 13);
            this.label16.TabIndex = 186;
            this.label16.Text = "Invoice No:";
            // 
            // txtInvoicePAY
            // 
            this.txtInvoicePAY.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtInvoicePAY.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInvoicePAY.Enabled = false;
            this.txtInvoicePAY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.txtInvoicePAY.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInvoicePAY.Location = new System.Drawing.Point(996, 8);
            this.txtInvoicePAY.Name = "txtInvoicePAY";
            this.txtInvoicePAY.Size = new System.Drawing.Size(50, 13);
            this.txtInvoicePAY.TabIndex = 185;
            this.txtInvoicePAY.Text = "1";
            // 
            // lblInvoiceNOPAY
            // 
            this.lblInvoiceNOPAY.AutoSize = true;
            this.lblInvoiceNOPAY.Location = new System.Drawing.Point(1057, 7);
            this.lblInvoiceNOPAY.Name = "lblInvoiceNOPAY";
            this.lblInvoiceNOPAY.Size = new System.Drawing.Size(10, 13);
            this.lblInvoiceNOPAY.TabIndex = 187;
            this.lblInvoiceNOPAY.Text = "-";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(129, 118);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(43, 13);
            this.linkLabel2.TabIndex = 184;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Split Bill";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked_1);
            // 
            // labelReffranceNo
            // 
            this.labelReffranceNo.AutoSize = true;
            this.labelReffranceNo.Enabled = false;
            this.labelReffranceNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReffranceNo.Location = new System.Drawing.Point(244, 127);
            this.labelReffranceNo.Name = "labelReffranceNo";
            this.labelReffranceNo.Size = new System.Drawing.Size(81, 16);
            this.labelReffranceNo.TabIndex = 183;
            this.labelReffranceNo.Text = "Reference #";
            // 
            // lblPaid
            // 
            this.lblPaid.AutoSize = true;
            this.lblPaid.Location = new System.Drawing.Point(178, 64);
            this.lblPaid.Name = "lblPaid";
            this.lblPaid.Size = new System.Drawing.Size(13, 13);
            this.lblPaid.TabIndex = 181;
            this.lblPaid.Text = "0";
            // 
            // GridPayment
            // 
            this.GridPayment.AllowUserToAddRows = false;
            this.GridPayment.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GridPayment.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridPayment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridPayment.Location = new System.Drawing.Point(10, 451);
            this.GridPayment.Name = "GridPayment";
            this.GridPayment.RowHeadersVisible = false;
            this.GridPayment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridPayment.Size = new System.Drawing.Size(552, 156);
            this.GridPayment.TabIndex = 180;
            this.GridPayment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridPayment_CellContentClick);
            // 
            // linkLabelAddNew
            // 
            this.linkLabelAddNew.AutoSize = true;
            this.linkLabelAddNew.Location = new System.Drawing.Point(511, 63);
            this.linkLabelAddNew.Name = "linkLabelAddNew";
            this.linkLabelAddNew.Size = new System.Drawing.Size(51, 13);
            this.linkLabelAddNew.TabIndex = 179;
            this.linkLabelAddNew.TabStop = true;
            this.linkLabelAddNew.Text = "Add New";
            this.linkLabelAddNew.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // lblTotalpayableAmtPY
            // 
            this.lblTotalpayableAmtPY.AutoSize = true;
            this.lblTotalpayableAmtPY.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalpayableAmtPY.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotalpayableAmtPY.Location = new System.Drawing.Point(355, 15);
            this.lblTotalpayableAmtPY.Name = "lblTotalpayableAmtPY";
            this.lblTotalpayableAmtPY.Size = new System.Drawing.Size(30, 23);
            this.lblTotalpayableAmtPY.TabIndex = 178;
            this.lblTotalpayableAmtPY.Text = "00";
            this.lblTotalpayableAmtPY.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1TotalPayable
            // 
            this.label1TotalPayable.AutoSize = true;
            this.label1TotalPayable.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1TotalPayable.ForeColor = System.Drawing.Color.Red;
            this.label1TotalPayable.Location = new System.Drawing.Point(242, 15);
            this.label1TotalPayable.Name = "label1TotalPayable";
            this.label1TotalPayable.Size = new System.Drawing.Size(119, 23);
            this.label1TotalPayable.TabIndex = 177;
            this.label1TotalPayable.Text = "Total Payable:";
            // 
            // labelShortcuts
            // 
            this.labelShortcuts.AutoSize = true;
            this.labelShortcuts.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.labelShortcuts.Location = new System.Drawing.Point(613, 20);
            this.labelShortcuts.Name = "labelShortcuts";
            this.labelShortcuts.Size = new System.Drawing.Size(45, 12);
            this.labelShortcuts.TabIndex = 176;
            this.labelShortcuts.Text = "Shortcuts";
            // 
            // lblCustID
            // 
            this.lblCustID.AutoSize = true;
            this.lblCustID.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.lblCustID.Location = new System.Drawing.Point(336, 64);
            this.lblCustID.Name = "lblCustID";
            this.lblCustID.Size = new System.Drawing.Size(10, 12);
            this.lblCustID.TabIndex = 171;
            this.lblCustID.Text = "1";
            // 
            // labelInsertCustomeramount
            // 
            this.labelInsertCustomeramount.AutoSize = true;
            this.labelInsertCustomeramount.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.labelInsertCustomeramount.Location = new System.Drawing.Point(11, 116);
            this.labelInsertCustomeramount.Name = "labelInsertCustomeramount";
            this.labelInsertCustomeramount.Size = new System.Drawing.Size(105, 12);
            this.labelInsertCustomeramount.TabIndex = 170;
            this.labelInsertCustomeramount.Text = "Insert Customer amount";
            // 
            // label1Optional
            // 
            this.label1Optional.AutoSize = true;
            this.label1Optional.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.label1Optional.Location = new System.Drawing.Point(244, 276);
            this.label1Optional.Name = "label1Optional";
            this.label1Optional.Size = new System.Drawing.Size(39, 12);
            this.label1Optional.TabIndex = 168;
            this.label1Optional.Text = "Optional";
            // 
            // labelComment
            // 
            this.labelComment.AutoSize = true;
            this.labelComment.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelComment.Location = new System.Drawing.Point(10, 282);
            this.labelComment.Name = "labelComment";
            this.labelComment.Size = new System.Drawing.Size(78, 18);
            this.labelComment.TabIndex = 167;
            this.labelComment.Text = "Comment:";
            // 
            // labelDue
            // 
            this.labelDue.AutoSize = true;
            this.labelDue.Enabled = false;
            this.labelDue.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDue.Location = new System.Drawing.Point(10, 228);
            this.labelDue.Name = "labelDue";
            this.labelDue.Size = new System.Drawing.Size(43, 18);
            this.labelDue.TabIndex = 166;
            this.labelDue.Text = "Due :";
            // 
            // label1ChangeAmount
            // 
            this.label1ChangeAmount.AutoSize = true;
            this.label1ChangeAmount.Enabled = false;
            this.label1ChangeAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1ChangeAmount.Location = new System.Drawing.Point(10, 177);
            this.label1ChangeAmount.Name = "label1ChangeAmount";
            this.label1ChangeAmount.Size = new System.Drawing.Size(122, 18);
            this.label1ChangeAmount.TabIndex = 164;
            this.label1ChangeAmount.Text = "Change Amount :";
            // 
            // labelPaidAmount
            // 
            this.labelPaidAmount.AutoSize = true;
            this.labelPaidAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPaidAmount.Location = new System.Drawing.Point(10, 59);
            this.labelPaidAmount.Name = "labelPaidAmount";
            this.labelPaidAmount.Size = new System.Drawing.Size(100, 18);
            this.labelPaidAmount.TabIndex = 163;
            this.labelPaidAmount.Text = "Paid Amount :";
            // 
            // labelPayby
            // 
            this.labelPayby.AutoSize = true;
            this.labelPayby.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPayby.Location = new System.Drawing.Point(244, 177);
            this.labelPayby.Name = "labelPayby";
            this.labelPayby.Size = new System.Drawing.Size(60, 18);
            this.labelPayby.TabIndex = 162;
            this.labelPayby.Text = "Pay by :";
            // 
            // labelSalesDate
            // 
            this.labelSalesDate.AutoSize = true;
            this.labelSalesDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSalesDate.Location = new System.Drawing.Point(244, 230);
            this.labelSalesDate.Name = "labelSalesDate";
            this.labelSalesDate.Size = new System.Drawing.Size(80, 18);
            this.labelSalesDate.TabIndex = 155;
            this.labelSalesDate.Text = "Sales Date";
            // 
            // dtSalesDate
            // 
            this.dtSalesDate.CustomFormat = "";
            this.dtSalesDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtSalesDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtSalesDate.Location = new System.Drawing.Point(246, 251);
            this.dtSalesDate.Name = "dtSalesDate";
            this.dtSalesDate.Size = new System.Drawing.Size(316, 22);
            this.dtSalesDate.TabIndex = 4;
            // 
            // RefrashPayby
            // 
            this.RefrashPayby.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.RefrashPayby.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.RefrashPayby.FlatAppearance.BorderSize = 0;
            this.RefrashPayby.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.RefrashPayby.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RefrashPayby.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.RefrashPayby.Image = ((System.Drawing.Image)(resources.GetObject("RefrashPayby.Image")));
            this.RefrashPayby.Location = new System.Drawing.Point(567, 200);
            this.RefrashPayby.Name = "RefrashPayby";
            this.RefrashPayby.Size = new System.Drawing.Size(25, 25);
            this.RefrashPayby.TabIndex = 204;
            this.RefrashPayby.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.RefrashPayby.UseVisualStyleBackColor = false;
            this.RefrashPayby.Click += new System.EventHandler(this.RefrashPayby_Click);
            // 
            // btnrefrash
            // 
            this.btnrefrash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnrefrash.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnrefrash.FlatAppearance.BorderSize = 0;
            this.btnrefrash.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnrefrash.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefrash.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnrefrash.Image = ((System.Drawing.Image)(resources.GetObject("btnrefrash.Image")));
            this.btnrefrash.Location = new System.Drawing.Point(568, 87);
            this.btnrefrash.Name = "btnrefrash";
            this.btnrefrash.Size = new System.Drawing.Size(25, 25);
            this.btnrefrash.TabIndex = 203;
            this.btnrefrash.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnrefrash.UseVisualStyleBackColor = false;
            this.btnrefrash.Click += new System.EventHandler(this.btnrefrash_Click);
            // 
            // tabPageSR_Split_Bill
            // 
            this.tabPageSR_Split_Bill.Controls.Add(this.panel7);
            this.tabPageSR_Split_Bill.ImageKey = "Split Bill.jpg";
            this.tabPageSR_Split_Bill.Location = new System.Drawing.Point(4, 34);
            this.tabPageSR_Split_Bill.Name = "tabPageSR_Split_Bill";
            this.tabPageSR_Split_Bill.Size = new System.Drawing.Size(927, 626);
            this.tabPageSR_Split_Bill.TabIndex = 2;
            this.tabPageSR_Split_Bill.Text = "Split Bill     ";
            this.tabPageSR_Split_Bill.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnSaveSplit);
            this.panel7.Controls.Add(this.btnSplitPrint);
            this.panel7.Controls.Add(this.splitContainer3);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(921, 608);
            this.panel7.TabIndex = 186;
            this.panel7.Visible = false;
            // 
            // splitContainer3
            // 
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.Location = new System.Drawing.Point(3, 6);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.btnAmountsplit);
            this.splitContainer3.Panel1.Controls.Add(this.btnItemSplit);
            this.splitContainer3.Panel1.Controls.Add(this.lblPaid1);
            this.splitContainer3.Panel1.Controls.Add(this.lblTotalPayment);
            this.splitContainer3.Panel1.Controls.Add(this.lblMaxNOBill);
            this.splitContainer3.Panel1.Controls.Add(this.label17);
            this.splitContainer3.Panel1.Controls.Add(this.label15);
            this.splitContainer3.Panel1.Controls.Add(this.button2);
            this.splitContainer3.Panel1.Controls.Add(this.linkLabel1);
            this.splitContainer3.Panel1.Controls.Add(this.btnSave);
            this.splitContainer3.Panel1.Controls.Add(this.label14);
            this.splitContainer3.Panel1.Controls.Add(this.comboPaytype);
            this.splitContainer3.Panel1.Controls.Add(this.txtSplitReffrance);
            this.splitContainer3.Panel1.Controls.Add(this.label11);
            this.splitContainer3.Panel1.Controls.Add(this.ComboSplitCustomer);
            this.splitContainer3.Panel1.Controls.Add(this.textSlpitAmt);
            this.splitContainer3.Panel1.Controls.Add(this.label10);
            this.splitContainer3.Panel1.Controls.Add(this.label7);
            this.splitContainer3.Panel1.Controls.Add(this.textSlpitNO);
            this.splitContainer3.Panel1.Controls.Add(this.label6);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.dataGridPaymentSplit);
            this.splitContainer3.Size = new System.Drawing.Size(621, 589);
            this.splitContainer3.SplitterDistance = 183;
            this.splitContainer3.TabIndex = 192;
            // 
            // btnAmountsplit
            // 
            this.btnAmountsplit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAmountsplit.FlatAppearance.BorderSize = 0;
            this.btnAmountsplit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAmountsplit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAmountsplit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAmountsplit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnAmountsplit.ForeColor = System.Drawing.Color.Black;
            this.btnAmountsplit.Location = new System.Drawing.Point(447, 13);
            this.btnAmountsplit.Name = "btnAmountsplit";
            this.btnAmountsplit.Size = new System.Drawing.Size(104, 27);
            this.btnAmountsplit.TabIndex = 210;
            this.btnAmountsplit.Text = "Amount Split";
            this.btnAmountsplit.UseVisualStyleBackColor = false;
            this.btnAmountsplit.Click += new System.EventHandler(this.btnAmountsplit_Click);
            // 
            // btnItemSplit
            // 
            this.btnItemSplit.BackColor = System.Drawing.Color.Green;
            this.btnItemSplit.FlatAppearance.BorderSize = 0;
            this.btnItemSplit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnItemSplit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnItemSplit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnItemSplit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnItemSplit.ForeColor = System.Drawing.Color.White;
            this.btnItemSplit.Location = new System.Drawing.Point(296, 13);
            this.btnItemSplit.Name = "btnItemSplit";
            this.btnItemSplit.Size = new System.Drawing.Size(104, 27);
            this.btnItemSplit.TabIndex = 209;
            this.btnItemSplit.Text = "Item Split";
            this.btnItemSplit.UseVisualStyleBackColor = false;
            this.btnItemSplit.Click += new System.EventHandler(this.btnItemSplit_Click);
            // 
            // lblPaid1
            // 
            this.lblPaid1.AutoSize = true;
            this.lblPaid1.Location = new System.Drawing.Point(172, 78);
            this.lblPaid1.Name = "lblPaid1";
            this.lblPaid1.Size = new System.Drawing.Size(13, 13);
            this.lblPaid1.TabIndex = 208;
            this.lblPaid1.Text = "0";
            // 
            // lblTotalPayment
            // 
            this.lblTotalPayment.AutoSize = true;
            this.lblTotalPayment.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPayment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotalPayment.Location = new System.Drawing.Point(129, 13);
            this.lblTotalPayment.Name = "lblTotalPayment";
            this.lblTotalPayment.Size = new System.Drawing.Size(30, 23);
            this.lblTotalPayment.TabIndex = 188;
            this.lblTotalPayment.Text = "00";
            this.lblTotalPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMaxNOBill
            // 
            this.lblMaxNOBill.AutoSize = true;
            this.lblMaxNOBill.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaxNOBill.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblMaxNOBill.Location = new System.Drawing.Point(141, 53);
            this.lblMaxNOBill.Name = "lblMaxNOBill";
            this.lblMaxNOBill.Size = new System.Drawing.Size(21, 15);
            this.lblMaxNOBill.TabIndex = 196;
            this.lblMaxNOBill.Text = "00";
            this.lblMaxNOBill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(14, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(119, 23);
            this.label17.TabIndex = 187;
            this.label17.Text = "Total Payable:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(12, 50);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(130, 18);
            this.label15.TabIndex = 207;
            this.label15.Text = "Maximum No of Bill :";
            // 
            // button2
            // 
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(557, 87);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(25, 25);
            this.button2.TabIndex = 206;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(500, 116);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(51, 13);
            this.linkLabel1.TabIndex = 197;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Add New";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnSave.ForeColor = System.Drawing.Color.Black;
            this.btnSave.Location = new System.Drawing.Point(451, 140);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(104, 27);
            this.btnSave.TabIndex = 205;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 16);
            this.label14.TabIndex = 201;
            this.label14.Text = "Pay by :";
            // 
            // comboPaytype
            // 
            this.comboPaytype.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboPaytype.FormattingEnabled = true;
            this.comboPaytype.Items.AddRange(new object[] {
            "Cash",
            "Debit Card",
            "Credit Card",
            "Interac",
            "Check ",
            "Gift Card",
            "PayPal",
            "Skrill/MoneyBrooker",
            "Payza",
            "ApplePay",
            "PayTM",
            "MasterCard",
            "Bank TT"});
            this.comboPaytype.Location = new System.Drawing.Point(15, 141);
            this.comboPaytype.Name = "comboPaytype";
            this.comboPaytype.Size = new System.Drawing.Size(197, 26);
            this.comboPaytype.TabIndex = 198;
            this.comboPaytype.Text = "Cash";
            // 
            // txtSplitReffrance
            // 
            this.txtSplitReffrance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSplitReffrance.Location = new System.Drawing.Point(235, 140);
            this.txtSplitReffrance.Name = "txtSplitReffrance";
            this.txtSplitReffrance.Size = new System.Drawing.Size(186, 26);
            this.txtSplitReffrance.TabIndex = 199;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(232, 122);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 16);
            this.label11.TabIndex = 202;
            this.label11.Text = "Reference #";
            // 
            // ComboSplitCustomer
            // 
            this.ComboSplitCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ComboSplitCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ComboSplitCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboSplitCustomer.FormattingEnabled = true;
            this.ComboSplitCustomer.Location = new System.Drawing.Point(235, 87);
            this.ComboSplitCustomer.Name = "ComboSplitCustomer";
            this.ComboSplitCustomer.Size = new System.Drawing.Size(316, 26);
            this.ComboSplitCustomer.TabIndex = 200;
            this.ComboSplitCustomer.Text = "Guest";
            // 
            // textSlpitAmt
            // 
            this.textSlpitAmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSlpitAmt.Location = new System.Drawing.Point(117, 93);
            this.textSlpitAmt.Name = "textSlpitAmt";
            this.textSlpitAmt.Size = new System.Drawing.Size(90, 26);
            this.textSlpitAmt.TabIndex = 194;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(233, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 16);
            this.label10.TabIndex = 203;
            this.label10.Text = "Customer  :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(114, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 195;
            this.label7.Text = "Bill Amt";
            // 
            // textSlpitNO
            // 
            this.textSlpitNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSlpitNO.Location = new System.Drawing.Point(15, 93);
            this.textSlpitNO.Name = "textSlpitNO";
            this.textSlpitNO.Size = new System.Drawing.Size(73, 26);
            this.textSlpitNO.TabIndex = 192;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 16);
            this.label6.TabIndex = 193;
            this.label6.Text = "No OF Bill";
            // 
            // dataGridPaymentSplit
            // 
            this.dataGridPaymentSplit.AllowUserToAddRows = false;
            this.dataGridPaymentSplit.AllowUserToResizeColumns = false;
            this.dataGridPaymentSplit.AllowUserToResizeRows = false;
            this.dataGridPaymentSplit.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridPaymentSplit.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridPaymentSplit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridPaymentSplit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPaymentSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridPaymentSplit.Location = new System.Drawing.Point(0, 0);
            this.dataGridPaymentSplit.Name = "dataGridPaymentSplit";
            this.dataGridPaymentSplit.RowHeadersVisible = false;
            this.dataGridPaymentSplit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridPaymentSplit.Size = new System.Drawing.Size(621, 402);
            this.dataGridPaymentSplit.TabIndex = 181;
            this.dataGridPaymentSplit.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridPaymentSplit_CellContentClick);
            // 
            // tabCashier
            // 
            this.tabCashier.Controls.Add(this.splitContainer1);
            this.tabCashier.ImageKey = "Cashier1.jpg";
            this.tabCashier.Location = new System.Drawing.Point(4, 34);
            this.tabCashier.Name = "tabCashier";
            this.tabCashier.Size = new System.Drawing.Size(927, 626);
            this.tabCashier.TabIndex = 3;
            this.tabCashier.Text = "Cashier     ";
            this.tabCashier.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Window;
            this.splitContainer1.Panel1.Controls.Add(this.btnCustCode);
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.txtSearchCustCode);
            this.splitContainer1.Panel1.Controls.Add(this.txtCas);
            this.splitContainer1.Panel1.Controls.Add(this.chkdiscredit);
            this.splitContainer1.Panel1.Controls.Add(this.btnSerchCashier);
            this.splitContainer1.Panel1.Controls.Add(this.lblMsg);
            this.splitContainer1.Panel1.Controls.Add(this.btnCashierRefresh);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.txtInvoiceCash);
            this.splitContainer1.Panel1.Controls.Add(this.dtStartDate);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.lblStartDate);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Window;
            this.splitContainer1.Panel2.Controls.Add(this.datagrdReportDetails);
            this.splitContainer1.Size = new System.Drawing.Size(927, 626);
            this.splitContainer1.SplitterDistance = 82;
            this.splitContainer1.TabIndex = 2;
            // 
            // btnCustCode
            // 
            this.btnCustCode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCustCode.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCustCode.FlatAppearance.BorderSize = 0;
            this.btnCustCode.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCustCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnCustCode.Image = ((System.Drawing.Image)(resources.GetObject("btnCustCode.Image")));
            this.btnCustCode.Location = new System.Drawing.Point(314, 45);
            this.btnCustCode.Name = "btnCustCode";
            this.btnCustCode.Size = new System.Drawing.Size(25, 25);
            this.btnCustCode.TabIndex = 202;
            this.btnCustCode.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCustCode.UseVisualStyleBackColor = false;
            this.btnCustCode.Click += new System.EventHandler(this.btnCustCode_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(207, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 16);
            this.label8.TabIndex = 101;
            this.label8.Text = "Customer Code";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txtSearchCustCode
            // 
            this.txtSearchCustCode.Location = new System.Drawing.Point(209, 49);
            this.txtSearchCustCode.Name = "txtSearchCustCode";
            this.txtSearchCustCode.Size = new System.Drawing.Size(99, 20);
            this.txtSearchCustCode.TabIndex = 201;
            this.txtSearchCustCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearchCustCode_KeyDown);
            this.txtSearchCustCode.Leave += new System.EventHandler(this.txtSearchCustCode_Leave);
            // 
            // txtCas
            // 
            this.txtCas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCas.Font = new System.Drawing.Font("Microsoft Sans Serif", 1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCas.Location = new System.Drawing.Point(1185, 7);
            this.txtCas.Name = "txtCas";
            this.txtCas.Size = new System.Drawing.Size(28, 2);
            this.txtCas.TabIndex = 99;
            // 
            // chkdiscredit
            // 
            this.chkdiscredit.AutoSize = true;
            this.chkdiscredit.Location = new System.Drawing.Point(577, 7);
            this.chkdiscredit.Name = "chkdiscredit";
            this.chkdiscredit.Size = new System.Drawing.Size(53, 17);
            this.chkdiscredit.TabIndex = 98;
            this.chkdiscredit.Text = "Credit";
            this.chkdiscredit.UseVisualStyleBackColor = true;
            this.chkdiscredit.CheckedChanged += new System.EventHandler(this.chkdiscredit_CheckedChanged);
            // 
            // btnSerchCashier
            // 
            this.btnSerchCashier.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSerchCashier.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSerchCashier.FlatAppearance.BorderSize = 0;
            this.btnSerchCashier.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSerchCashier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSerchCashier.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnSerchCashier.Image = ((System.Drawing.Image)(resources.GetObject("btnSerchCashier.Image")));
            this.btnSerchCashier.Location = new System.Drawing.Point(588, 45);
            this.btnSerchCashier.Name = "btnSerchCashier";
            this.btnSerchCashier.Size = new System.Drawing.Size(25, 25);
            this.btnSerchCashier.TabIndex = 204;
            this.btnSerchCashier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSerchCashier.UseVisualStyleBackColor = false;
            this.btnSerchCashier.Click += new System.EventHandler(this.btnSerchCashier_Click);
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.lblMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMsg.Location = new System.Drawing.Point(115, 11);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(10, 13);
            this.lblMsg.TabIndex = 95;
            this.lblMsg.Text = "-";
            // 
            // btnCashierRefresh
            // 
            this.btnCashierRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCashierRefresh.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCashierRefresh.FlatAppearance.BorderSize = 0;
            this.btnCashierRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCashierRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCashierRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnCashierRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnCashierRefresh.Image")));
            this.btnCashierRefresh.Location = new System.Drawing.Point(155, 46);
            this.btnCashierRefresh.Name = "btnCashierRefresh";
            this.btnCashierRefresh.Size = new System.Drawing.Size(25, 25);
            this.btnCashierRefresh.TabIndex = 94;
            this.btnCashierRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCashierRefresh.UseVisualStyleBackColor = false;
            this.btnCashierRefresh.Click += new System.EventHandler(this.btnCashierRefresh_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.label2.Location = new System.Drawing.Point(8, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 93;
            this.label2.Text = "Today";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(403, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 16);
            this.label1.TabIndex = 92;
            this.label1.Text = "Invoice No / Customer";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtInvoiceCash
            // 
            this.txtInvoiceCash.Location = new System.Drawing.Point(406, 49);
            this.txtInvoiceCash.Name = "txtInvoiceCash";
            this.txtInvoiceCash.Size = new System.Drawing.Size(176, 20);
            this.txtInvoiceCash.TabIndex = 203;
            this.txtInvoiceCash.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInvoiceCash_KeyDown);
            this.txtInvoiceCash.Leave += new System.EventHandler(this.txtInvoiceCash_Leave);
            // 
            // dtStartDate
            // 
            this.dtStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.dtStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtStartDate.Location = new System.Drawing.Point(15, 49);
            this.dtStartDate.Name = "dtStartDate";
            this.dtStartDate.Size = new System.Drawing.Size(130, 21);
            this.dtStartDate.TabIndex = 90;
            this.dtStartDate.ValueChanged += new System.EventHandler(this.dtStartDate_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 16);
            this.label9.TabIndex = 88;
            this.label9.Text = "Report by date";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(49, 10);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(31, 13);
            this.lblStartDate.TabIndex = 0;
            this.lblStartDate.Text = "____";
            // 
            // datagrdReportDetails
            // 
            this.datagrdReportDetails.AllowUserToAddRows = false;
            this.datagrdReportDetails.AllowUserToDeleteRows = false;
            this.datagrdReportDetails.AllowUserToResizeColumns = false;
            this.datagrdReportDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.Black;
            this.datagrdReportDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.datagrdReportDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagrdReportDetails.BackgroundColor = System.Drawing.Color.White;
            this.datagrdReportDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagrdReportDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.datagrdReportDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Times New Roman", 11F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagrdReportDetails.DefaultCellStyle = dataGridViewCellStyle19;
            this.datagrdReportDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datagrdReportDetails.Location = new System.Drawing.Point(0, 0);
            this.datagrdReportDetails.Name = "datagrdReportDetails";
            this.datagrdReportDetails.ReadOnly = true;
            this.datagrdReportDetails.RowHeadersVisible = false;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.Black;
            this.datagrdReportDetails.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.datagrdReportDetails.RowTemplate.Height = 44;
            this.datagrdReportDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagrdReportDetails.Size = new System.Drawing.Size(927, 540);
            this.datagrdReportDetails.TabIndex = 2;
            this.datagrdReportDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagrdReportDetails_CellClick);
            this.datagrdReportDetails.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.datagrdReportDetails_DataBindingComplete);
            // 
            // tabDelivery
            // 
            this.tabDelivery.Controls.Add(this.splitContainer2);
            this.tabDelivery.ImageKey = "Driver3.png";
            this.tabDelivery.Location = new System.Drawing.Point(4, 34);
            this.tabDelivery.Name = "tabDelivery";
            this.tabDelivery.Size = new System.Drawing.Size(927, 626);
            this.tabDelivery.TabIndex = 4;
            this.tabDelivery.Text = "Delivery       ";
            this.tabDelivery.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.BackColor = System.Drawing.Color.White;
            this.splitContainer2.Panel1.Controls.Add(this.dtDriverStartDate);
            this.splitContainer2.Panel1.Controls.Add(this.button1);
            this.splitContainer2.Panel1.Controls.Add(this.txtReciptNO);
            this.splitContainer2.Panel1.Controls.Add(this.label3);
            this.splitContainer2.Panel1.Controls.Add(this.label4);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dtGrdvOrderDetails);
            this.splitContainer2.Size = new System.Drawing.Size(927, 626);
            this.splitContainer2.SplitterDistance = 65;
            this.splitContainer2.TabIndex = 2;
            // 
            // dtDriverStartDate
            // 
            this.dtDriverStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.dtDriverStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDriverStartDate.Location = new System.Drawing.Point(22, 34);
            this.dtDriverStartDate.Name = "dtDriverStartDate";
            this.dtDriverStartDate.Size = new System.Drawing.Size(130, 21);
            this.dtDriverStartDate.TabIndex = 97;
            this.dtDriverStartDate.ValueChanged += new System.EventHandler(this.dtDriverStartDate_ValueChanged);
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(184, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(25, 25);
            this.button1.TabIndex = 96;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtReciptNO
            // 
            this.txtReciptNO.Location = new System.Drawing.Point(233, 33);
            this.txtReciptNO.Name = "txtReciptNO";
            this.txtReciptNO.Size = new System.Drawing.Size(241, 20);
            this.txtReciptNO.TabIndex = 89;
            this.txtReciptNO.TextChanged += new System.EventHandler(this.txtReciptNO_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(230, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 15);
            this.label3.TabIndex = 88;
            this.label3.Text = "Receipt No";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(19, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 31;
            this.label4.Text = "From Date";
            // 
            // dtGrdvOrderDetails
            // 
            this.dtGrdvOrderDetails.AllowUserToAddRows = false;
            this.dtGrdvOrderDetails.AllowUserToDeleteRows = false;
            this.dtGrdvOrderDetails.AllowUserToResizeColumns = false;
            this.dtGrdvOrderDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black;
            this.dtGrdvOrderDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dtGrdvOrderDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtGrdvOrderDetails.BackgroundColor = System.Drawing.Color.White;
            this.dtGrdvOrderDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtGrdvOrderDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dtGrdvOrderDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Times New Roman", 12F);
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtGrdvOrderDetails.DefaultCellStyle = dataGridViewCellStyle23;
            this.dtGrdvOrderDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtGrdvOrderDetails.Location = new System.Drawing.Point(0, 0);
            this.dtGrdvOrderDetails.Name = "dtGrdvOrderDetails";
            this.dtGrdvOrderDetails.ReadOnly = true;
            this.dtGrdvOrderDetails.RowHeadersVisible = false;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.Black;
            this.dtGrdvOrderDetails.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.dtGrdvOrderDetails.RowTemplate.Height = 44;
            this.dtGrdvOrderDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGrdvOrderDetails.Size = new System.Drawing.Size(927, 557);
            this.dtGrdvOrderDetails.TabIndex = 2;
            this.dtGrdvOrderDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGrdvOrderDetails_CellClick);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(263, 22);
            this.toolStripMenuItem18.Text = "Add New Customer";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(149, 6);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.toolStripMenuItem1.Text = "General Ledger Report";
            this.toolStripMenuItem1.Visible = false;
            // 
            // contextMenu_Sales
            // 
            this.contextMenu_Sales.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reAssignDriverToolStripMenuItem});
            this.contextMenu_Sales.Name = "contextMenu_Sales";
            this.contextMenu_Sales.Size = new System.Drawing.Size(157, 26);
            // 
            // reAssignDriverToolStripMenuItem
            // 
            this.reAssignDriverToolStripMenuItem.Name = "reAssignDriverToolStripMenuItem";
            this.reAssignDriverToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.reAssignDriverToolStripMenuItem.Text = "ReAssign Driver";
            // 
            // lblClear
            // 
            this.lblClear.AutoSize = true;
            this.lblClear.Location = new System.Drawing.Point(30, 669);
            this.lblClear.Name = "lblClear";
            this.lblClear.Size = new System.Drawing.Size(10, 13);
            this.lblClear.TabIndex = 176;
            this.lblClear.Text = "-";
            this.lblClear.TextChanged += new System.EventHandler(this.lblClear_TextChanged);
            // 
            // lblDraft
            // 
            this.lblDraft.AutoSize = true;
            this.lblDraft.Location = new System.Drawing.Point(48, 669);
            this.lblDraft.Name = "lblDraft";
            this.lblDraft.Size = new System.Drawing.Size(10, 13);
            this.lblDraft.TabIndex = 177;
            this.lblDraft.Text = "-";
            this.lblDraft.TextChanged += new System.EventHandler(this.lblDraft_TextChanged);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem8.Image")));
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.toolStripMenuItem8.Size = new System.Drawing.Size(263, 22);
            this.toolStripMenuItem8.Text = "Purchase product/Add Item";
            // 
            // addSaleToolStripMenuItem
            // 
            this.addSaleToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addSaleToolStripMenuItem.Image")));
            this.addSaleToolStripMenuItem.Name = "addSaleToolStripMenuItem";
            this.addSaleToolStripMenuItem.Size = new System.Drawing.Size(263, 22);
            this.addSaleToolStripMenuItem.Text = "Add Sale";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem6.Image")));
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.toolStripMenuItem6.Size = new System.Drawing.Size(185, 22);
            this.toolStripMenuItem6.Text = "Sales Register";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem10.Image")));
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(185, 22);
            this.toolStripMenuItem10.Text = "Return Product";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem12.Image")));
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.toolStripMenuItem12.Size = new System.Drawing.Size(193, 22);
            this.toolStripMenuItem12.Text = "Stock Items List";
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem13.Image")));
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.toolStripMenuItem13.Size = new System.Drawing.Size(193, 22);
            this.toolStripMenuItem13.Text = "Sales Report";
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem14.Image")));
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(193, 22);
            this.toolStripMenuItem14.Text = "Overview";
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem15.Image")));
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(193, 22);
            this.toolStripMenuItem15.Text = "Sales Chart";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem16.Image")));
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.toolStripMenuItem16.Size = new System.Drawing.Size(193, 22);
            this.toolStripMenuItem16.Text = "Due List";
            // 
            // lblCustomerPage
            // 
            this.lblCustomerPage.AutoSize = true;
            this.lblCustomerPage.Location = new System.Drawing.Point(7, 669);
            this.lblCustomerPage.Name = "lblCustomerPage";
            this.lblCustomerPage.Size = new System.Drawing.Size(10, 13);
            this.lblCustomerPage.TabIndex = 183;
            this.lblCustomerPage.Text = "-";
            // 
            // lblIsCustAdvanceAmtYN
            // 
            this.lblIsCustAdvanceAmtYN.AutoSize = true;
            this.lblIsCustAdvanceAmtYN.Location = new System.Drawing.Point(71, 669);
            this.lblIsCustAdvanceAmtYN.Name = "lblIsCustAdvanceAmtYN";
            this.lblIsCustAdvanceAmtYN.Size = new System.Drawing.Size(10, 13);
            this.lblIsCustAdvanceAmtYN.TabIndex = 184;
            this.lblIsCustAdvanceAmtYN.Text = "-";
            // 
            // lblCustPage4Cashier
            // 
            this.lblCustPage4Cashier.AutoSize = true;
            this.lblCustPage4Cashier.Location = new System.Drawing.Point(100, 669);
            this.lblCustPage4Cashier.Name = "lblCustPage4Cashier";
            this.lblCustPage4Cashier.Size = new System.Drawing.Size(10, 13);
            this.lblCustPage4Cashier.TabIndex = 185;
            this.lblCustPage4Cashier.Text = "-";
            // 
            // SalesRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(940, 690);
            this.Controls.Add(this.lblCustPage4Cashier);
            this.Controls.Add(this.lblIsCustAdvanceAmtYN);
            this.Controls.Add(this.lblCustomerPage);
            this.Controls.Add(this.lblDraft);
            this.Controls.Add(this.lblClear);
            this.Controls.Add(this.tabSRcontrol);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SalesRegister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Register";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SalesRegister_FormClosing);
            this.Load += new System.EventHandler(this.SalesRegister_Load);
            this.ItemcartPanel.ResumeLayout(false);
            this.ItemcartPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvSalesItemList)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.PanelCategoryList.ResumeLayout(false);
            this.PanelCategoryList.PerformLayout();
            this.tabSRcontrol.ResumeLayout(false);
            this.tabPageSR_Counter.ResumeLayout(false);
            this.tabPageSR_Counter.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ItemButton.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.ItemGrid.ResumeLayout(false);
            this.PanelStockList1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgrvProductList)).EndInit();
            this.ItemsImage.ResumeLayout(false);
            this.PanelStockList.ResumeLayout(false);
            this.PanelStockList.PerformLayout();
            this.RelatedItems.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.Catagories.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tabPageSR_Payment.ResumeLayout(false);
            this.tabPageSR_Payment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridPayment)).EndInit();
            this.tabPageSR_Split_Bill.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPaymentSplit)).EndInit();
            this.tabCashier.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagrdReportDetails)).EndInit();
            this.tabDelivery.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdvOrderDetails)).EndInit();
            this.contextMenu_Sales.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel ItemcartPanel;
        private System.Windows.Forms.DataGridView dgrvSalesItemList;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblsubtotal;
        private System.Windows.Forms.Label labelSubTotal;
        private System.Windows.Forms.Label lblTotalPayable;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label labelDiscount;
        private System.Windows.Forms.Button btnSuspend;
        private System.Windows.Forms.TextBox txtInvoice;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.LinkLabel helplnk;
        private System.Windows.Forms.LinkLabel linkLabelCalculator;
        private System.Windows.Forms.Button btnSalesCredit;
        private System.Windows.Forms.TabControl tabSRcontrol;
        private System.Windows.Forms.TabPage tabPageSR_Counter;
        private System.Windows.Forms.TabPage tabPageSR_Payment;
        private System.Windows.Forms.Label labelSalesDate;
        private System.Windows.Forms.DateTimePicker dtSalesDate;
        private System.Windows.Forms.Label lblCustID;
        private System.Windows.Forms.ComboBox ComboCustID;
        private System.Windows.Forms.Label labelInsertCustomeramount;
        private System.Windows.Forms.Label label1Optional;
        private System.Windows.Forms.Label labelComment;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.TextBox txtDueAmount;
        private System.Windows.Forms.Label labelDue;
        private System.Windows.Forms.TextBox txtPaidAmount;
        private System.Windows.Forms.TextBox txtChangeAmount;
        private System.Windows.Forms.Label label1ChangeAmount;
        private System.Windows.Forms.Label labelPaidAmount;
        private System.Windows.Forms.Label labelPayby;
        private System.Windows.Forms.ComboBox CombPayby;
        private System.Windows.Forms.Button btnSaveOnly;
        private System.Windows.Forms.Button btnCompleteSalesAndPrint;
        private System.Windows.Forms.Button btnback;
        private SalesRagister.Currency_Shortcuts currency_Shortcuts1;
        private System.Windows.Forms.Label labelShortcuts;
        private System.Windows.Forms.Label lblTotalpayableAmtPY;
        private System.Windows.Forms.Label label1TotalPayable;
        private System.Windows.Forms.LinkLabel linkLabelAddNew;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.DataGridView GridPayment;
        private System.Windows.Forms.Label lblPaid;
        private System.Windows.Forms.TextBox txtReffrance;
        private System.Windows.Forms.Label labelReffranceNo;
        private System.Windows.Forms.Label lblInvoiceNO;
        private System.Windows.Forms.Label lblOrderway;
        private System.Windows.Forms.ComboBox comboSalesMan;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Panel PanelCategoryList;
        private System.Windows.Forms.FlowLayoutPanel flwLyoutCategoryPanel;
        private System.Windows.Forms.LinkLabel linkLabelRefresh;
        private System.Windows.Forms.Label labelDeliveryCharge;
        private System.Windows.Forms.Label lblDeliveryChargis;
        private System.Windows.Forms.TextBox lbloveralldiscount;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtDiscountRate;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnCashAndPrint;
        private System.Windows.Forms.TextBox txtcashRecived;
        private System.Windows.Forms.Label labelCashReceived;
        private System.Windows.Forms.Label lblChangeAmt;
        private System.Windows.Forms.Label labelChangeamount;
        private System.Windows.Forms.Button btnDraft;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PageSetupDialog MyPrintPreviewDialog;
        private System.Windows.Forms.Button btnCOD;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem addSaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenu_Sales;
        private System.Windows.Forms.ToolStripMenuItem reAssignDriverToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label lblorderNO;
        private System.Windows.Forms.Label lblPerishable;
        private System.Windows.Forms.ComboBox comboTable;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPageSR_Split_Bill;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView dataGridPaymentSplit;
        private System.Windows.Forms.Label lblTotalPayment;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.LinkLabel linkbtnSlpit;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Label lblMaxNOBill;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboPaytype;
        private System.Windows.Forms.TextBox txtSplitReffrance;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox ComboSplitCustomer;
        private System.Windows.Forms.TextBox textSlpitAmt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textSlpitNO;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSaveSplit;
        private System.Windows.Forms.Button btnSplitPrint;
        private System.Windows.Forms.Label lblPaid1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Button btnAmountsplit;
        private System.Windows.Forms.Button btnItemSplit;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtInvoicePAY;
        private System.Windows.Forms.Label lblInvoiceNOPAY;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Label lblDraft;
        private System.Windows.Forms.CheckBox chkCreditTrans;
        private System.Windows.Forms.Label lblstart;
        private System.Windows.Forms.Button btnrefrash;
        private System.Windows.Forms.Button RefrashPayby;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel lnkCustomer;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dtsaleDate;
        private System.Windows.Forms.RadioButton radiocredit;
        private System.Windows.Forms.RadioButton radioCash;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ItemsImage;
        private System.Windows.Forms.Panel PanelStockList;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelItemList;
        private System.Windows.Forms.TabPage RelatedItems;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel PenalRelateditems;
        private System.Windows.Forms.TabPage Catagories;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel PanelCatagories;
        private System.Windows.Forms.TabPage tabCashier;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.CheckBox chkdiscredit;
        private System.Windows.Forms.Button btnSerchCashier;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Button btnCashierRefresh;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInvoiceCash;
        private System.Windows.Forms.DateTimePicker dtStartDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.DataGridView datagrdReportDetails;
        private System.Windows.Forms.TabPage tabDelivery;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.DateTimePicker dtDriverStartDate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtReciptNO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dtGrdvOrderDetails;
        private System.Windows.Forms.TabPage ItemGrid;
        private System.Windows.Forms.Panel PanelStockList1;
        private System.Windows.Forms.DataGridView dgrvProductList;
        private System.Windows.Forms.TextBox txtCas;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.CheckBox chkWithGrid;
        private System.Windows.Forms.Button btnSerchItem;
        private System.Windows.Forms.TextBox txtSearchItem;
        private System.Windows.Forms.TextBox txtBarcodeReaderBox;
        private System.Windows.Forms.CheckBox chkoutput;
        private System.Windows.Forms.CheckBox chkImage;
        private System.Windows.Forms.Label itemCount;
        private System.Windows.Forms.Label lblCatagory;
        private System.Windows.Forms.Label labelSearchItems;
        private System.Windows.Forms.Label lblInsertitembarcode;
        private System.Windows.Forms.CheckBox chkbutton;
        private System.Windows.Forms.TabPage ItemButton;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelItemListButton;
        private System.Windows.Forms.Label lblCustomerPage;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btnAppGridAdd;
        private System.Windows.Forms.Label lblSerialize;
        private System.Windows.Forms.Label lblIsReciepe;
        private System.Windows.Forms.Label lblDeliverydate;
        private System.Windows.Forms.DateTimePicker dtsaleDeliveryDate;
        private System.Windows.Forms.Button btnBooking;
        private System.Windows.Forms.Button btnCustCode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSearchCustCode;
        private System.Windows.Forms.Label lblCustAvailableAmt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblmainCustwalletant;
        private System.Windows.Forms.Label lblIsCustAdvanceAmtYN;
        private System.Windows.Forms.Label lblCustPage4Cashier;
    }
}