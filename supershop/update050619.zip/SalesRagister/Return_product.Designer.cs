﻿namespace supershop
{
    partial class Return_product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Return_product));
            this.lblEmpID = new System.Windows.Forms.Label();
            this.dtgrdviewReturnItem = new System.Windows.Forms.DataGridView();
            this.lblMsg = new System.Windows.Forms.Label();
            this.txtbarcodeinputer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.lblsubtotal = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtDiscountRate = new System.Windows.Forms.TextBox();
            this.lbloveralldiscount = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.vatIncreasebtn = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.lblTotalReturn = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtVATRate = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lblvat = new System.Windows.Forms.Label();
            this.lbldis = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Suspen = new System.Windows.Forms.Button();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.txtReturnAmount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Calculator = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboReason = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblReturnID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCustID = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblSalesby = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.CmbPayType = new System.Windows.Forms.ComboBox();
            this.ReturnSave = new System.Windows.Forms.Button();
            this.dtReturnDate = new System.Windows.Forms.DateTimePicker();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lblDue = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbltrxType = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblsalestime = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblShopid = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblInvoiceNO = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lblsalesID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblPaidAmount = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblpaytype = new System.Windows.Forms.Label();
            this.lblorderNO = new System.Windows.Forms.Label();
            this.chkWastage = new System.Windows.Forms.CheckBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblSerialize = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrdviewReturnItem)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblEmpID
            // 
            this.lblEmpID.AutoSize = true;
            this.lblEmpID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpID.Location = new System.Drawing.Point(46, 31);
            this.lblEmpID.Name = "lblEmpID";
            this.lblEmpID.Size = new System.Drawing.Size(42, 13);
            this.lblEmpID.TabIndex = 0;
            this.lblEmpID.Text = "=====";
            // 
            // dtgrdviewReturnItem
            // 
            this.dtgrdviewReturnItem.AllowUserToAddRows = false;
            this.dtgrdviewReturnItem.AllowUserToResizeRows = false;
            this.dtgrdviewReturnItem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgrdviewReturnItem.BackgroundColor = System.Drawing.Color.White;
            this.dtgrdviewReturnItem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Constantia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgrdviewReturnItem.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgrdviewReturnItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgrdviewReturnItem.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgrdviewReturnItem.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dtgrdviewReturnItem.Location = new System.Drawing.Point(68, 119);
            this.dtgrdviewReturnItem.Name = "dtgrdviewReturnItem";
            this.dtgrdviewReturnItem.RowHeadersVisible = false;
            this.dtgrdviewReturnItem.RowTemplate.Height = 30;
            this.dtgrdviewReturnItem.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgrdviewReturnItem.Size = new System.Drawing.Size(598, 258);
            this.dtgrdviewReturnItem.TabIndex = 144;
            this.dtgrdviewReturnItem.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dtgrdviewReturnItem.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgrdviewReturnItem_CellEndEdit);
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Location = new System.Drawing.Point(362, 65);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(52, 13);
            this.lblMsg.TabIndex = 143;
            this.lblMsg.Text = "not found";
            this.lblMsg.Visible = false;
            // 
            // txtbarcodeinputer
            // 
            this.txtbarcodeinputer.BackColor = System.Drawing.SystemColors.Menu;
            this.txtbarcodeinputer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbarcodeinputer.Location = new System.Drawing.Point(68, 89);
            this.txtbarcodeinputer.Name = "txtbarcodeinputer";
            this.txtbarcodeinputer.Size = new System.Drawing.Size(419, 22);
            this.txtbarcodeinputer.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtbarcodeinputer, "Insert Invoice number / Receipt number");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(64, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(274, 21);
            this.label2.TabIndex = 142;
            this.label2.Text = "Insert Sold Invoice no :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.lblsubtotal);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.txtDiscountRate);
            this.panel2.Controls.Add(this.lbloveralldiscount);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.vatIncreasebtn);
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.lblTotalReturn);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.txtVATRate);
            this.panel2.Controls.Add(this.lblTotal);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.lblvat);
            this.panel2.Controls.Add(this.lbldis);
            this.panel2.Location = new System.Drawing.Point(68, 399);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(598, 159);
            this.panel2.TabIndex = 6;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 18);
            this.label13.TabIndex = 173;
            this.label13.Text = "Sub Total";
            // 
            // lblsubtotal
            // 
            this.lblsubtotal.AutoSize = true;
            this.lblsubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.lblsubtotal.Location = new System.Drawing.Point(208, 51);
            this.lblsubtotal.Name = "lblsubtotal";
            this.lblsubtotal.Size = new System.Drawing.Size(18, 20);
            this.lblsubtotal.TabIndex = 166;
            this.lblsubtotal.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(416, 34);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 13);
            this.label17.TabIndex = 165;
            this.label17.Text = "%";
            // 
            // txtDiscountRate
            // 
            this.txtDiscountRate.BackColor = System.Drawing.SystemColors.Info;
            this.txtDiscountRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiscountRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscountRate.Location = new System.Drawing.Point(382, 34);
            this.txtDiscountRate.Name = "txtDiscountRate";
            this.txtDiscountRate.ReadOnly = true;
            this.txtDiscountRate.Size = new System.Drawing.Size(28, 13);
            this.txtDiscountRate.TabIndex = 164;
            this.txtDiscountRate.Text = "0";
            this.toolTip1.SetToolTip(this.txtDiscountRate, "Over all Discount Rate");
            // 
            // lbloveralldiscount
            // 
            this.lbloveralldiscount.AutoSize = true;
            this.lbloveralldiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F);
            this.lbloveralldiscount.Location = new System.Drawing.Point(457, 14);
            this.lbloveralldiscount.Name = "lbloveralldiscount";
            this.lbloveralldiscount.Size = new System.Drawing.Size(10, 12);
            this.lbloveralldiscount.TabIndex = 163;
            this.lbloveralldiscount.Text = "0";
            this.toolTip1.SetToolTip(this.lbloveralldiscount, "Over all Total Discount ");
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F);
            this.label16.Location = new System.Drawing.Point(377, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 162;
            this.label16.Text = "Overall Discount:";
            // 
            // vatIncreasebtn
            // 
            this.vatIncreasebtn.FlatAppearance.BorderSize = 0;
            this.vatIncreasebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vatIncreasebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vatIncreasebtn.Location = new System.Drawing.Point(448, 27);
            this.vatIncreasebtn.Name = "vatIncreasebtn";
            this.vatIncreasebtn.Size = new System.Drawing.Size(19, 25);
            this.vatIncreasebtn.TabIndex = 0;
            this.vatIncreasebtn.Text = "+";
            this.toolTip1.SetToolTip(this.vatIncreasebtn, "Press (+) For Increase Discount Rate");
            this.vatIncreasebtn.UseVisualStyleBackColor = true;
            this.vatIncreasebtn.Click += new System.EventHandler(this.disIncreasebtn_Click);
            // 
            // button12
            // 
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(474, 27);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(24, 25);
            this.button12.TabIndex = 1;
            this.button12.Text = "--";
            this.toolTip1.SetToolTip(this.button12, "Press (-) For Decrease Discount Rate");
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.disDecrease_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(5, 111);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(581, 20);
            this.label32.TabIndex = 135;
            this.label32.Text = "====================================================";
            // 
            // lblTotalReturn
            // 
            this.lblTotalReturn.AutoSize = true;
            this.lblTotalReturn.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalReturn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTotalReturn.Location = new System.Drawing.Point(208, 133);
            this.lblTotalReturn.Name = "lblTotalReturn";
            this.lblTotalReturn.Size = new System.Drawing.Size(20, 22);
            this.lblTotalReturn.TabIndex = 134;
            this.lblTotalReturn.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.label29.Location = new System.Drawing.Point(5, 5);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(51, 20);
            this.label29.TabIndex = 123;
            this.label29.Text = "Total:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.label30.ForeColor = System.Drawing.Color.Red;
            this.label30.Location = new System.Drawing.Point(3, 134);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(168, 20);
            this.label30.TabIndex = 125;
            this.label30.Text = "Total Return Amount:";
            // 
            // txtVATRate
            // 
            this.txtVATRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVATRate.Location = new System.Drawing.Point(85, 92);
            this.txtVATRate.Name = "txtVATRate";
            this.txtVATRate.Size = new System.Drawing.Size(50, 13);
            this.txtVATRate.TabIndex = 3;
            this.txtVATRate.Text = "0";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.lblTotal.Location = new System.Drawing.Point(208, 5);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(18, 20);
            this.lblTotal.TabIndex = 133;
            this.lblTotal.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(136, 92);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 13);
            this.label12.TabIndex = 100;
            this.label12.Text = "%";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 16);
            this.label11.TabIndex = 131;
            this.label11.Text = "VAT Rate:";
            this.toolTip1.SetToolTip(this.label11, "(+) VAT  Rate  or  \r\n( - ) Figure Calculate as Discount Rate \r\n");
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(5, 30);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(89, 16);
            this.label28.TabIndex = 132;
            this.label28.Text = "Discount rate:";
            // 
            // lblvat
            // 
            this.lblvat.AutoSize = true;
            this.lblvat.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.75F);
            this.lblvat.Location = new System.Drawing.Point(208, 87);
            this.lblvat.Name = "lblvat";
            this.lblvat.Size = new System.Drawing.Size(18, 20);
            this.lblvat.TabIndex = 49;
            this.lblvat.Text = "0";
            // 
            // lbldis
            // 
            this.lbldis.AutoSize = true;
            this.lbldis.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.75F);
            this.lbldis.Location = new System.Drawing.Point(208, 27);
            this.lbldis.Name = "lbldis";
            this.lbldis.Size = new System.Drawing.Size(18, 20);
            this.lbldis.TabIndex = 51;
            this.lbldis.Text = "0";
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 800;
            this.toolTip1.AutoPopDelay = 80000;
            this.toolTip1.BackColor = System.Drawing.Color.OliveDrab;
            this.toolTip1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.toolTip1.InitialDelay = 10;
            this.toolTip1.ReshowDelay = 10;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // Suspen
            // 
            this.Suspen.BackColor = System.Drawing.Color.White;
            this.Suspen.FlatAppearance.BorderSize = 0;
            this.Suspen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Suspen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Suspen.ForeColor = System.Drawing.Color.Blue;
            this.Suspen.Image = ((System.Drawing.Image)(resources.GetObject("Suspen.Image")));
            this.Suspen.Location = new System.Drawing.Point(821, 602);
            this.Suspen.Name = "Suspen";
            this.Suspen.Size = new System.Drawing.Size(149, 60);
            this.Suspen.TabIndex = 4;
            this.Suspen.Text = "Suspend";
            this.Suspen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTip1.SetToolTip(this.Suspen, "Press For Cancel Transaction");
            this.Suspen.UseVisualStyleBackColor = false;
            this.Suspen.Visible = false;
            this.Suspen.Click += new System.EventHandler(this.Suspen_Click);
            // 
            // txtComment
            // 
            this.txtComment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComment.Location = new System.Drawing.Point(136, 265);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(184, 81);
            this.txtComment.TabIndex = 4;
            this.toolTip1.SetToolTip(this.txtComment, "Comment");
            // 
            // txtReturnAmount
            // 
            this.txtReturnAmount.Enabled = false;
            this.txtReturnAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReturnAmount.Location = new System.Drawing.Point(136, 75);
            this.txtReturnAmount.Name = "txtReturnAmount";
            this.txtReturnAmount.Size = new System.Drawing.Size(184, 31);
            this.txtReturnAmount.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtReturnAmount, "Insert Your amount");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 22);
            this.label6.TabIndex = 147;
            this.label6.Text = "Return Items";
            // 
            // Calculator
            // 
            this.Calculator.BackColor = System.Drawing.Color.White;
            this.Calculator.FlatAppearance.BorderSize = 0;
            this.Calculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Calculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculator.ForeColor = System.Drawing.Color.Navy;
            this.Calculator.Image = ((System.Drawing.Image)(resources.GetObject("Calculator.Image")));
            this.Calculator.Location = new System.Drawing.Point(799, 517);
            this.Calculator.Name = "Calculator";
            this.Calculator.Size = new System.Drawing.Size(99, 61);
            this.Calculator.TabIndex = 5;
            this.Calculator.Text = "Calculator";
            this.Calculator.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Calculator.UseVisualStyleBackColor = false;
            this.Calculator.Click += new System.EventHandler(this.button11_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Orange;
            this.groupBox1.Controls.Add(this.comboReason);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.lblCustomerName);
            this.groupBox1.Controls.Add(this.lblReturnID);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblCustID);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.lblSalesby);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.txtComment);
            this.groupBox1.Controls.Add(this.txtReturnAmount);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.CmbPayType);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(694, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(338, 377);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment";
            // 
            // comboReason
            // 
            this.comboReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboReason.FormattingEnabled = true;
            this.comboReason.Location = new System.Drawing.Point(136, 171);
            this.comboReason.Name = "comboReason";
            this.comboReason.Size = new System.Drawing.Size(184, 26);
            this.comboReason.TabIndex = 177;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(22, 176);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(98, 16);
            this.label23.TabIndex = 176;
            this.label23.Text = "Return reason :";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F);
            this.lblCustomerName.Location = new System.Drawing.Point(140, 133);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(10, 13);
            this.lblCustomerName.TabIndex = 174;
            this.lblCustomerName.Text = "-";
            // 
            // lblReturnID
            // 
            this.lblReturnID.AutoSize = true;
            this.lblReturnID.Location = new System.Drawing.Point(219, 20);
            this.lblReturnID.Name = "lblReturnID";
            this.lblReturnID.Size = new System.Drawing.Size(12, 16);
            this.lblReturnID.TabIndex = 173;
            this.lblReturnID.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(46, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 16);
            this.label4.TabIndex = 105;
            this.label4.Text = "Customer  :";
            // 
            // lblCustID
            // 
            this.lblCustID.AutoSize = true;
            this.lblCustID.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.75F);
            this.lblCustID.Location = new System.Drawing.Point(136, 113);
            this.lblCustID.Name = "lblCustID";
            this.lblCustID.Size = new System.Drawing.Size(55, 13);
            this.lblCustID.TabIndex = 104;
            this.lblCustID.Text = "10000009";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(56, 351);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(64, 16);
            this.label24.TabIndex = 172;
            this.label24.Text = "Sales by:";
            // 
            // lblSalesby
            // 
            this.lblSalesby.AutoSize = true;
            this.lblSalesby.Location = new System.Drawing.Point(136, 351);
            this.lblSalesby.Name = "lblSalesby";
            this.lblSalesby.Size = new System.Drawing.Size(12, 16);
            this.lblSalesby.TabIndex = 171;
            this.lblSalesby.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(17, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 12);
            this.label3.TabIndex = 73;
            this.label3.Text = "Return";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(21, 94);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(82, 12);
            this.label39.TabIndex = 72;
            this.label39.Text = "Insert Your amount";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.label35.Location = new System.Drawing.Point(78, 281);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(39, 12);
            this.label35.TabIndex = 70;
            this.label35.Text = "Optional";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(46, 265);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(71, 16);
            this.label34.TabIndex = 69;
            this.label34.Text = "Comment :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(16, 72);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 16);
            this.label19.TabIndex = 60;
            this.label19.Text = "Return Amount :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(17, 44);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(102, 16);
            this.label18.TabIndex = 59;
            this.label18.Text = "Payment Type :";
            // 
            // CmbPayType
            // 
            this.CmbPayType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmbPayType.FormattingEnabled = true;
            this.CmbPayType.Items.AddRange(new object[] {
            "Cash",
            "Debit Card",
            "Credit Card",
            "Check ",
            "Gift Card",
            "Transfer",
            "Return"});
            this.CmbPayType.Location = new System.Drawing.Point(136, 39);
            this.CmbPayType.Name = "CmbPayType";
            this.CmbPayType.Size = new System.Drawing.Size(184, 26);
            this.CmbPayType.TabIndex = 0;
            this.CmbPayType.Text = "Cash";
            // 
            // ReturnSave
            // 
            this.ReturnSave.BackColor = System.Drawing.Color.Red;
            this.ReturnSave.FlatAppearance.BorderSize = 0;
            this.ReturnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReturnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.75F, System.Drawing.FontStyle.Bold);
            this.ReturnSave.ForeColor = System.Drawing.Color.Linen;
            this.ReturnSave.Location = new System.Drawing.Point(694, 472);
            this.ReturnSave.Name = "ReturnSave";
            this.ReturnSave.Size = new System.Drawing.Size(338, 39);
            this.ReturnSave.TabIndex = 3;
            this.ReturnSave.Text = "Save";
            this.ReturnSave.UseVisualStyleBackColor = false;
            this.ReturnSave.Click += new System.EventHandler(this.ReturnSave_Click);
            // 
            // dtReturnDate
            // 
            this.dtReturnDate.CustomFormat = "";
            this.dtReturnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtReturnDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtReturnDate.Location = new System.Drawing.Point(694, 9);
            this.dtReturnDate.Name = "dtReturnDate";
            this.dtReturnDate.Size = new System.Drawing.Size(289, 21);
            this.dtReturnDate.TabIndex = 148;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btnSubmit.Location = new System.Drawing.Point(493, 88);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(84, 24);
            this.btnSubmit.TabIndex = 151;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(74, 664);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(203, 13);
            this.label5.TabIndex = 158;
            this.label5.Text = "In Tax column 1 = Tax apply  0 =  No Tax";
            // 
            // lblDue
            // 
            this.lblDue.AutoSize = true;
            this.lblDue.Location = new System.Drawing.Point(76, 21);
            this.lblDue.Name = "lblDue";
            this.lblDue.Size = new System.Drawing.Size(13, 13);
            this.lblDue.TabIndex = 159;
            this.lblDue.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 13);
            this.label7.TabIndex = 160;
            this.label7.Text = "Due:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 162;
            this.label8.Text = "Change:";
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Location = new System.Drawing.Point(76, 41);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(13, 13);
            this.lblChange.TabIndex = 161;
            this.lblChange.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(136, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 13);
            this.label9.TabIndex = 166;
            this.label9.Text = "Transaction Type:";
            // 
            // lbltrxType
            // 
            this.lbltrxType.AutoSize = true;
            this.lbltrxType.Location = new System.Drawing.Point(237, 21);
            this.lbltrxType.Name = "lbltrxType";
            this.lbltrxType.Size = new System.Drawing.Size(10, 13);
            this.lbltrxType.TabIndex = 165;
            this.lbltrxType.Text = "-";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(359, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 13);
            this.label14.TabIndex = 164;
            this.label14.Text = "Sales Time:";
            // 
            // lblsalestime
            // 
            this.lblsalestime.AutoSize = true;
            this.lblsalestime.Location = new System.Drawing.Point(426, 41);
            this.lblsalestime.Name = "lblsalestime";
            this.lblsalestime.Size = new System.Drawing.Size(10, 13);
            this.lblsalestime.TabIndex = 163;
            this.lblsalestime.Text = "-";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(185, 41);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 13);
            this.label15.TabIndex = 168;
            this.label15.Text = "ShopID:";
            // 
            // lblShopid
            // 
            this.lblShopid.AutoSize = true;
            this.lblShopid.Location = new System.Drawing.Point(237, 41);
            this.lblShopid.Name = "lblShopid";
            this.lblShopid.Size = new System.Drawing.Size(10, 13);
            this.lblShopid.TabIndex = 167;
            this.lblShopid.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(198, 61);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 13);
            this.label10.TabIndex = 170;
            this.label10.Text = "Note:";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Location = new System.Drawing.Point(237, 61);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(10, 13);
            this.lblNote.TabIndex = 169;
            this.lblNote.Text = "-";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblInvoiceNO);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.lblsalesID);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.lblPaidAmount);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.lblpaytype);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.lblDue);
            this.groupBox2.Controls.Add(this.lblNote);
            this.groupBox2.Controls.Add(this.lblChange);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.lblShopid);
            this.groupBox2.Controls.Add(this.lblsalestime);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.lbltrxType);
            this.groupBox2.Location = new System.Drawing.Point(68, 559);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(598, 102);
            this.groupBox2.TabIndex = 171;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sales history";
            // 
            // lblInvoiceNO
            // 
            this.lblInvoiceNO.AutoSize = true;
            this.lblInvoiceNO.Location = new System.Drawing.Point(79, 83);
            this.lblInvoiceNO.Name = "lblInvoiceNO";
            this.lblInvoiceNO.Size = new System.Drawing.Size(10, 13);
            this.lblInvoiceNO.TabIndex = 178;
            this.lblInvoiceNO.Text = "-";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 83);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 13);
            this.label25.TabIndex = 177;
            this.label25.Text = "Invoice NO:";
            // 
            // lblsalesID
            // 
            this.lblsalesID.AutoSize = true;
            this.lblsalesID.Location = new System.Drawing.Point(426, 61);
            this.lblsalesID.Name = "lblsalesID";
            this.lblsalesID.Size = new System.Drawing.Size(10, 13);
            this.lblsalesID.TabIndex = 176;
            this.lblsalesID.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(371, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 175;
            this.label1.Text = "Sales ID:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 61);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 13);
            this.label22.TabIndex = 174;
            this.label22.Text = "Paid Amount:";
            // 
            // lblPaidAmount
            // 
            this.lblPaidAmount.AutoSize = true;
            this.lblPaidAmount.Location = new System.Drawing.Point(76, 61);
            this.lblPaidAmount.Name = "lblPaidAmount";
            this.lblPaidAmount.Size = new System.Drawing.Size(13, 13);
            this.lblPaidAmount.TabIndex = 173;
            this.lblPaidAmount.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(372, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 13);
            this.label20.TabIndex = 172;
            this.label20.Text = "Pay Tye:";
            // 
            // lblpaytype
            // 
            this.lblpaytype.AutoSize = true;
            this.lblpaytype.Location = new System.Drawing.Point(426, 21);
            this.lblpaytype.Name = "lblpaytype";
            this.lblpaytype.Size = new System.Drawing.Size(10, 13);
            this.lblpaytype.TabIndex = 171;
            this.lblpaytype.Text = "-";
            // 
            // lblorderNO
            // 
            this.lblorderNO.AutoSize = true;
            this.lblorderNO.Location = new System.Drawing.Point(629, 64);
            this.lblorderNO.Name = "lblorderNO";
            this.lblorderNO.Size = new System.Drawing.Size(10, 13);
            this.lblorderNO.TabIndex = 172;
            this.lblorderNO.Text = "-";
            // 
            // chkWastage
            // 
            this.chkWastage.AutoSize = true;
            this.chkWastage.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkWastage.Location = new System.Drawing.Point(594, 93);
            this.chkWastage.Name = "chkWastage";
            this.chkWastage.Size = new System.Drawing.Size(69, 17);
            this.chkWastage.TabIndex = 174;
            this.chkWastage.Text = "Wastage";
            this.chkWastage.UseVisualStyleBackColor = true;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F);
            this.label38.Location = new System.Drawing.Point(452, 65);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(114, 12);
            this.label38.TabIndex = 145;
            this.label38.Text = "Bar-Code Scanner Support";
            this.label38.Visible = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(65, 381);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(366, 13);
            this.label21.TabIndex = 175;
            this.label21.Text = "Note :Kindly Please keep the item that you want to remove from  this Invoice";
            // 
            // lblSerialize
            // 
            this.lblSerialize.AutoSize = true;
            this.lblSerialize.Location = new System.Drawing.Point(1035, 664);
            this.lblSerialize.Name = "lblSerialize";
            this.lblSerialize.Size = new System.Drawing.Size(10, 13);
            this.lblSerialize.TabIndex = 176;
            this.lblSerialize.Text = "-";
            this.lblSerialize.Visible = false;
            this.lblSerialize.TextChanged += new System.EventHandler(this.lblSerialize_TextChanged);
            // 
            // Return_product
            // 
            this.AcceptButton = this.btnSubmit;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1057, 683);
            this.Controls.Add(this.lblSerialize);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.chkWastage);
            this.Controls.Add(this.lblorderNO);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.dtReturnDate);
            this.Controls.Add(this.Calculator);
            this.Controls.Add(this.Suspen);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ReturnSave);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.dtgrdviewReturnItem);
            this.Controls.Add(this.lblEmpID);
            this.Controls.Add(this.txtbarcodeinputer);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.label2);
            this.Name = "Return_product";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Return Items";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Return_product_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgrdviewReturnItem)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmpID;
        private System.Windows.Forms.DataGridView dtgrdviewReturnItem;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.TextBox txtbarcodeinputer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button vatIncreasebtn;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label lblTotalReturn;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtVATRate;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblvat;
        private System.Windows.Forms.Label lbldis;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Calculator;
        private System.Windows.Forms.Button Suspen;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.TextBox txtReturnAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox CmbPayType;
        private System.Windows.Forms.Button ReturnSave;
        private System.Windows.Forms.DateTimePicker dtReturnDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblDue;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbltrxType;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblsalestime;
        private System.Windows.Forms.Label lbloveralldiscount;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblShopid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblSalesby;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtDiscountRate;
        private System.Windows.Forms.Label lblsubtotal;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblpaytype;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblPaidAmount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblsalesID;
        private System.Windows.Forms.Label lblReturnID;
        private System.Windows.Forms.Label lblorderNO;
        private System.Windows.Forms.CheckBox chkWastage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCustID;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblInvoiceNO;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboReason;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblSerialize;
    }
}