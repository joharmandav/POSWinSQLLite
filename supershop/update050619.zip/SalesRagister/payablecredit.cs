﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace supershop
{
    public partial class payablecredit : Form
    {
        public payablecredit()
        {
            InitializeComponent();
            dtReceiveDate.Format = DateTimePickerFormat.Custom;
            dtReceiveDate.CustomFormat = "yyyy-MM-dd";
        }

        public string CustName
        {
            set
            {
                ComboCustID.Text = value;
            }
            get
            {
                return ComboCustID.Text;
            }
        }

        bool FlagLoad;
        private void payablecredit_Load(object sender, EventArgs e)
        {
            FlagLoad = true;
            bindCostomer();
            BindPayType();

            firstbind();

            FlagLoad = false;
        }

        public void BindPayType()
        {
            string Sql = "Select * from REFTABLE where TenentID = " + Tenent.TenentID + " and RefType = 'Payment' and RefSubType = 'Method' and ShortName = 'POS' And ACTIVE = 'Y'";
            DataTable dt = DataAccess.GetDataTable(Sql);
            if (dt.Rows.Count > 0)
            {
                CombPayby.DataSource = dt;
                CombPayby.ValueMember = "REFID";
                CombPayby.DisplayMember = "REFNAME1";
            }
        }

        public void bindCostomer()
        {
            string sqlCust = " select ( Name || ' - ' || Phone || ' - ' || EmailAddress ) as 'Name',tbl_customer.ID , sales_item.InvoiceNO as Invoice " +
                             " from tbl_customer inner join sales_item on sales_item.TenentID = tbl_customer.TenentID and sales_item.C_id = tbl_customer.ID " +
                             " left join sales_payment on sales_item.sales_id = sales_payment.sales_id and sales_item.TenentID = sales_payment.TenentID " +
                             " where tbl_customer.TenentID = " + Tenent.TenentID + " and tbl_customer.PeopleType = 'Customer' and sales_item.ISPaymentCredit = 1 and " +
                             " (sales_payment.PaymentStutas is null or sales_payment.PaymentStutas = 'Pending' ) " +
                             " group by sales_item.C_id Order by Name";
            DataTable dtCust = DataAccess.GetDataTable(sqlCust);

            if (dtCust.Rows.Count > 0)
            {
                ComboCustID.DataSource = dtCust;
                ComboCustID.DisplayMember = "Name";
                ComboCustID.ValueMember = "ID";

                getInvoice(ComboCustID.SelectedValue.ToString());

            }
        }

        public void getInvoice(string CID)
        {
            string sqlCust = " select tbl_customer.ID , sales_item.InvoiceNO as Invoice " +
                             " from tbl_customer inner join sales_item on sales_item.TenentID = tbl_customer.TenentID and sales_item.C_id = '" + CID + "' " +
                             " left join sales_payment on sales_item.sales_id = sales_payment.sales_id and sales_item.TenentID = sales_payment.TenentID " +
                             " where tbl_customer.TenentID = " + Tenent.TenentID + " and tbl_customer.PeopleType = 'Customer' and sales_item.ISPaymentCredit = 1 and " +
                             " (sales_payment.PaymentStutas is null or sales_payment.PaymentStutas = 'Pending' ) and sales_item.C_id = '" + CID + "'  " +
                             " group by sales_item.C_id Order by Name";
            DataTable dtCust = DataAccess.GetDataTable(sqlCust);
            ComboInvoice.DataSource = dtCust;
            ComboInvoice.DisplayMember = "Invoice";
            ComboInvoice.ValueMember = "Invoice";
        }

        public void firstbind()
        {

            if (ComboInvoice.Text != null && ComboInvoice.Text != "" && ComboInvoice.Text != "System.Data.DataRowView")
            {
                int Cid = Convert.ToInt32(ComboCustID.SelectedValue);
                string Sql = " select  (sum(sales_item.total) - (case when  sales_payment.payment_amount is not null then  sales_payment.payment_amount when sales_payment.payment_amount is null then 0 End )) as Total " +
                             " from sales_item left join sales_payment on sales_item.sales_id = sales_payment.sales_id and sales_item.TenentID = sales_payment.TenentID " +
                             " where sales_item.TenentID=" + Tenent.TenentID + " and sales_item.PaymentMode = 'Credit' and " +
                             " sales_item.C_id = " + Cid + " and sales_item.InvoiceNO = '" + ComboInvoice.Text + "' and (sales_payment.PaymentStutas is null or sales_payment.PaymentStutas = 'Pending' )";
                DataTable dt = DataAccess.GetDataTable(Sql);

                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["Total"] != null)
                    {
                        decimal Total_Payble = dt.Rows[0]["Total"].ToString() != "" ? Convert.ToDecimal(dt.Rows[0]["Total"]) : 0;
                        txttotalamt.Text = Total_Payble.ToString();
                        txtReceive.Text = "0";
                        txtAfterPaid.Text = Total_Payble.ToString();
                    }
                    else
                    {
                        txttotalamt.Text = "0";
                        txtReceive.Text = "0";
                        txtAfterPaid.Text = "0";
                    }
                }

            }
            else
            {
                txttotalamt.Text = "0";
                txtReceive.Text = "0";
                txtAfterPaid.Text = "0";
            }
        }

        private void ComboCustID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (FlagLoad == false)
            {
                getInvoice(ComboCustID.SelectedValue.ToString());

            }
        }

        private void txtReceive_Leave(object sender, EventArgs e)
        {
            try
            {
                decimal Total_Payble = Convert.ToDecimal(txttotalamt.Text);
                decimal Enter = Convert.ToDecimal(txtReceive.Text);

                decimal rest = Total_Payble - Enter;

                if (rest < 0)
                {
                    lblMsg.Text = "Not Allow To More Than " + Total_Payble + " Amount";
                    btnSave.Enabled = false;
                }
                else
                {
                    txtAfterPaid.Text = (Math.Round(rest, 3)).ToString();
                    btnSave.Enabled = true;
                }
            }
            catch
            {

            }
        }


        private void txtReceive_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    decimal Total_Payble = Convert.ToDecimal(txttotalamt.Text);
                    decimal Enter = Convert.ToDecimal(txtReceive.Text);

                    decimal rest = Total_Payble - Enter;

                    if (rest < 0)
                    {
                        lblMsg.Text = "Not Allow To More Than " + Total_Payble + " Amount";
                        btnSave.Enabled = false;
                    }
                    else
                    {
                        txtAfterPaid.Text = (Math.Round(rest, 3)).ToString();
                        btnSave.Enabled = true;
                    }
                }
                catch
                {

                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "";

            string payment_type = CombPayby.Text;
            if (payment_type.ToUpper() != "CASH" && txtRefrance.Text == "")
            {
                lblMsg.Text = "Please Enter Reference #";
                return;
            }

            decimal Total_Payble = Convert.ToDecimal(txttotalamt.Text);
            decimal Enter = Convert.ToDecimal(txtReceive.Text);

            decimal rest = Total_Payble - Enter;

            if (Enter == 0)
            {
                lblMsg.Text = "Please Enter Paid Amount";
                btnSave.Enabled = false;
                return;
            }
            else if (rest < 0)
            {
                lblMsg.Text = "Not Allow To More Than " + Total_Payble + " Amount";
                btnSave.Enabled = false;
                return;
            }
            else
            {

            }

            int C_ID = Convert.ToInt32(ComboCustID.SelectedValue);
            string Customer = ComboCustID.Text.ToString().Split('-')[0].Trim();

            string Sql = " select sales_item.sales_id as 'sales_id',sales_item.InvoiceNO as 'InvoiceNO', (sum(sales_item.total) - (case when  sales_payment.payment_amount is not null then  sales_payment.payment_amount when sales_payment.payment_amount is null then 0 End )) as Total " +
                         " from sales_item left join sales_payment on sales_item.sales_id = sales_payment.sales_id and sales_item.TenentID = sales_payment.TenentID " +
                         " where sales_item.TenentID=" + Tenent.TenentID + " and sales_item.PaymentMode = 'Credit' and " +
                         " sales_item.C_id = " + C_ID + " and (sales_payment.PaymentStutas is null or sales_payment.PaymentStutas = 'Pending' )" +
                         " group by sales_item.sales_id";
            DataTable dt = DataAccess.GetDataTable(Sql);

            decimal PayRest = Enter;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                int sales_ID = Convert.ToInt32(dt.Rows[i]["sales_id"]);
                string InvoiceNO = dt.Rows[i]["InvoiceNO"].ToString();
                decimal Total = Convert.ToDecimal(dt.Rows[i]["Total"]);

                decimal payamount = 0;

                string PaymentStutas = "";
                if (PayRest >= Total)
                {
                    payamount = Total;
                    PaymentStutas = "Success";
                }
                else
                {
                    payamount = Total - PayRest;
                    PaymentStutas = "Pending";
                }

                decimal changeamount = 0;
                decimal dueamount = 0;
                string salesdate = dtReceiveDate.Text;
                string Comment = Customer;


                List<PaymentDatasale> GridPayment = new List<PaymentDatasale>();

                PaymentDatasale Obj = new PaymentDatasale();

                Obj.invoice = sales_ID.ToString();
                Obj.Reffrance_NO = txtRefrance.Text;
                Obj.payment_type = payment_type;
                Obj.payment_amount = payamount;

                GridPayment.Add(Obj);

                if (PayRest > 0)
                {
                    SalesRegister.payment_item_Credit(sales_ID, InvoiceNO, C_ID, Customer, payamount, changeamount, dueamount, salesdate, Comment, PaymentStutas, GridPayment);

                    PayRest = PayRest - Total;
                }
                else
                {
                    PayRest = PayRest - Total;
                }
            }
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (Application.OpenForms["Add_PaymentType"] != null)
            {
                Application.OpenForms["Add_PaymentType"].Close();
                Add_PaymentType go = new Add_PaymentType();
                go.Show();

            }
            else
            {
                Add_PaymentType go = new Add_PaymentType();
                go.Show();
            }
        }

        private void RefrashPayby_Click(object sender, EventArgs e)
        {
            BindPayType();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (Application.OpenForms["CreditCustomerSearch"] != null)
            {
                Application.OpenForms["CreditCustomerSearch"].Close();
            }
            this.Refresh();

            CreditCustomerSearch go = new CreditCustomerSearch();
            go.Show();
        }

        private void payablecredit_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                txtReceive_Leave(sender, e);

                MoveForm.ReleaseCapture();
                MoveForm.SendMessage(Handle, MoveForm.WM_NCLBUTTONDOWN, MoveForm.HT_CAPTION, 0);
            }
        }

        private void ComboInvoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            firstbind();
        }

    }
}
